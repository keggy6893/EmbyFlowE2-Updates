EmbyFlow FTP-Anmeldung: 10 Accounts, LocalTest3

Nach Installation und Neustart: /etc/enigma2/embyflow_login.ini direkt per FTP bearbeiten.
Die Abschnitte [Account1] bis [Account10] werden automatisch angelegt.
Pro Account: name, server (mit http:// oder https://), username, password.
Leere Accounts werden ausgeblendet. Passwort kann leer sein.
EmbyFlow oeffnen: mit Hoch/Runter Account markieren, OK speichert und startet.
Blau liest FTP-Aenderungen neu. Rot/EXIT startet mit den bisher aktiven Daten.
Die Auswahl erscheint bei jedem Pluginstart, sobald Accounts eingetragen sind.
Der gewaehlte Account wird in /etc/enigma2/settings gespeichert.
Alte [EmbyFlow]-Anmeldedaten werden beim ersten Umstieg in Account1 uebernommen.
Vorhandene Account-Abschnitte werden nicht ueberschrieben; fehlende werden ergaenzt.
Passwoerter stehen im Klartext in der INI und settings.
Basis: ThemeVideos Test8. GitHub unveraendert. Box-Praxistest noch offen.
