# EmbyFlowE2 RC26.9 – Freinamenfix (Prüfversion)

Stand 16.11.2026. **Keine Installationsfreigabe.**

Ausgang: plugin_2026111523.py / SHA256 b7bcf3dc4bbefd4c938b7747258eb8bcbc061be0d303aa0b19c11ec31d7cdbb9

Korrigiert:
1. Audio-Player: scale_skin_value durch sx/sy ersetzt.
2. Synchronisierung: undefinierten user-Zugriff durch username ersetzt.
3. Grid/Trailer: fehlenden lokalen shutil-Import ergänzt.
4. Untertitel: Existenz aller drei Rücksetzfunktionen geprüft.

Python-AST-Syntaxprüfung und fünf eindeutige Ersetzungen bestätigt.
**Enigma2-Laufzeittest, GUI, Tonspuren, Grid und Bilder noch nicht geprüft.**
Die offizielle update.json und der Updatekanal bleiben unverändert.
