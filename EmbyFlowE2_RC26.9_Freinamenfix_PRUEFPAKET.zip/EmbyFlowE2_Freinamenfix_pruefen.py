#!/usr/bin/env python3
from pathlib import Path
import ast
import hashlib
p=Path(__file__).with_name("EmbyFlowE2_RC26.9_Freinamenfix_PRUEFVERSION.py")
data=p.read_bytes()
ast.parse(data.decode("utf-8"))
assert hashlib.sha256(data).hexdigest()=="bc7c2a7c4a1ecdfea6e1fcdc77de642c582e4c3faea28cdf9a5f4bfbfc6aa271"
print("Syntax und SHA256 OK – KEIN Enigma2-Laufzeittest")
