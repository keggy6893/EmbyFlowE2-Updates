param(
    [string]$Project = 'C:\Users\bumse\AndroidStudioProjects\EmbyFlowAndroid',
    [string]$Device = '192.168.1.4:5555'
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$utf8 = New-Object System.Text.UTF8Encoding($false)
$manifest = Get-Content -LiteralPath "$PSScriptRoot\manifest.json" -Raw | ConvertFrom-Json
foreach ($entry in $manifest.required.PSObject.Properties) {
    $file = Join-Path $Project $entry.Name
    if (-not (Test-Path -LiteralPath $file)) { throw "Projektdatei fehlt: $($entry.Name)" }
    if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -ne $entry.Value) {
        throw "Abweichender Quellstand: $($entry.Name). Nichts geaendert. Bitte Ausgabe im Chat zeigen."
    }
}
foreach ($entry in $manifest.payload.PSObject.Properties) {
    $file = Join-Path "$PSScriptRoot\payload" $entry.Name
    if (-not (Test-Path -LiteralPath $file)) { throw "Updatedatei fehlt: $($entry.Name)" }
    if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -ne $entry.Value) { throw "Updatedatei beschaedigt: $($entry.Name)" }
    $destination = Join-Path $Project $entry.Name
    if ((Test-Path -LiteralPath $destination) -and -not ($manifest.required.PSObject.Properties.Name -contains $entry.Name)) {
        throw "Neue Datei existiert bereits: $($entry.Name). Nichts geaendert."
    }
}
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$base = 'C:\Users\bumse\Downloads\EmbyFlowAndroid'
$backup = Join-Path $base "Sicherung_vor_Detail_$stamp"
$stage = Join-Path $base "Test_Detail_$stamp"
New-Item -ItemType Directory -Force -Path $base | Out-Null
foreach ($target in @($backup, $stage)) {
    robocopy $Project $target /E /XD build .gradle .git .idea .kotlin /R:1 /W:1 /NFL /NDL /NJH /NJS | Out-Null
    if ($LASTEXITCODE -ge 8) { throw "Kopieren fehlgeschlagen: $target" }
}
Write-Host "Quellen und Konfiguration gesichert: $backup" -ForegroundColor Green
foreach ($entry in $manifest.payload.PSObject.Properties) {
    $destination = Join-Path $stage $entry.Name
    New-Item -ItemType Directory -Force -Path (Split-Path $destination) | Out-Null
    Copy-Item -LiteralPath (Join-Path "$PSScriptRoot\payload" $entry.Name) -Destination $destination -Force
}
$previousJava = $env:JAVA_HOME
try {
    $studioJava = 'C:\Program Files\Android\Android Studio\jbr'
    if (Test-Path "$studioJava\bin\java.exe") { $env:JAVA_HOME = $studioJava }
    Write-Host 'Android-Build der Testkopie ...' -ForegroundColor Cyan
    Push-Location $stage
    try {
        & "$stage\gradlew.bat" assembleDebug --console=plain
        if ($LASTEXITCODE -ne 0) { throw "Build fehlgeschlagen. Originalprojekt unveraendert. Testkopie: $stage" }
    } finally { Pop-Location }
} finally { $env:JAVA_HOME = $previousJava }
$apk = Join-Path $stage 'app\build\outputs\apk\debug\app-debug.apk'
if (-not (Test-Path -LiteralPath $apk)) { throw 'APK nach Build nicht gefunden.' }
$adb = Join-Path $env:LOCALAPPDATA 'Android\Sdk\platform-tools\adb.exe'
if (-not (Test-Path -LiteralPath $adb)) { throw 'ADB fehlt. Originalprojekt unveraendert.' }
& $adb connect $Device
& $adb -s $Device get-state
if ($LASTEXITCODE -ne 0) { throw 'TV nicht verbunden. Originalprojekt unveraendert.' }
& $adb -s $Device install -r $apk
if ($LASTEXITCODE -ne 0) { throw 'Installation fehlgeschlagen. Keine App deinstalliert; Originalprojekt unveraendert.' }
foreach ($entry in $manifest.payload.PSObject.Properties) {
    $destination = Join-Path $Project $entry.Name
    New-Item -ItemType Directory -Force -Path (Split-Path $destination) | Out-Null
    Copy-Item -LiteralPath (Join-Path $stage $entry.Name) -Destination $destination -Force
}
& $adb -s $Device shell am start -n de.embyflow.androidtv/.MainActivity
if ($LASTEXITCODE -ne 0) { throw 'Installiert, App-Start fehlgeschlagen.' }
Write-Host 'Detail-Update installiert. Bitte Film und Serie oeffnen.' -ForegroundColor Green
Write-Host "APK: $apk"
Write-Host "Sicherung: $backup"
