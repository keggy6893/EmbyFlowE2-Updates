package de.embyflow.androidtv

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

// EMBYFLOW_NEUHEITEN_E2_LAYOUT

class NeuheitenActivity : Activity() {

    private data class Entry(
        val id: String,
        val title: String,
        val type: String,
        val year: Int,
        val parentId: String = ""
    )

    private val sections = listOf(
        "Alle Neuheiten",
        "Filme",
        "Serien",
        "Dokus",
        "Doku-Serien"
    )

    private var sectionIndex = 0
    private var selected = 0
    private var focusPosters = false
    private var generation = 0

    private var entries = emptyList<Entry>()
    private val posters = mutableMapOf<String, Bitmap>()

    private var message = "Lade Neuheiten ..."
    private var title = "Alle Neuheiten"

    private var seriesId = ""
    private var seriesTitle = ""
    private var seasonId = ""

    private lateinit var screen: NeuheitenView

    private val navy = Color.rgb(11, 24, 39)
    private val panel = Color.rgb(15, 33, 52)
    private val cyan = Color.rgb(21, 185, 255)
    private val white = Color.rgb(235, 240, 247)
    private val muted = Color.rgb(160, 173, 190)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        screen = NeuheitenView()
        setContentView(screen)

        val requestedSeries = intent.getStringExtra("open_series_id").orEmpty()
        if (requestedSeries.isNotBlank()) {
            seriesId = requestedSeries
            seriesTitle = intent.getStringExtra("open_series_title").orEmpty()
            focusPosters = true
            loadSection(seriesId)
        } else {
            loadSection()
        }
    }

    private fun loadSection(parentId: String = "") {
        val currentGeneration = ++generation

        entries = emptyList()
        posters.clear()
        selected = 0

        title = when {
            seasonId.isNotBlank() -> "Folgen: $seriesTitle"
            seriesId.isNotBlank() -> "Staffeln: $seriesTitle"
            else -> sections[sectionIndex]
        }

        message = "Lade Medien ..."
        screen.invalidate()

        val prefs = getSharedPreferences("embyflow", MODE_PRIVATE)
        val server = prefs.getString("server", "")
            .orEmpty().trimEnd('/')
        val token = prefs.getString("token", "").orEmpty()
        val userId = prefs.getString("userId", "").orEmpty()

        if (server.isBlank() || token.isBlank() || userId.isBlank()) {
            message = "Bitte zuerst mit Emby verbinden."
            screen.invalidate()
            return
        }

        thread {
            try {
                val types = when {
                    seasonId.isNotBlank() -> "Episode"
                    seriesId.isNotBlank() -> "Season"
                    sectionIndex == 1 || sectionIndex == 3 -> "Movie"
                    sectionIndex == 2 || sectionIndex == 4 -> "Series"
                    else -> "Movie,Series"
                }

                val params = mutableListOf(
                    "IncludeItemTypes=$types",
                    "Fields=Overview,Genres,DateCreated,ProductionYear",
                    "SortBy=${if (parentId.isNotBlank()) "IndexNumber,SortName" else "DateCreated"}",
                    "SortOrder=${if (parentId.isNotBlank()) "Ascending" else "Descending"}",
                    "Limit=120"
                )

                if (parentId.isNotBlank()) {
                    params.add("ParentId=$parentId")
                    params.add("Recursive=false")
                } else {
                    params.add("Recursive=true")
                }

                val url = "$server/Users/$userId/Items?" +
                    params.joinToString("&")

                val connection =
                    URL(url).openConnection() as HttpURLConnection

                connection.connectTimeout = 10000
                connection.readTimeout = 15000
                connection.setRequestProperty("X-Emby-Token", token)

                val response = try {
                    if (connection.responseCode != 200) {
                        throw Exception("Emby HTTP ${connection.responseCode}")
                    }
                    connection.inputStream.bufferedReader().use {
                        it.readText()
                    }
                } finally {
                    connection.disconnect()
                }

                val json = JSONObject(response)
                val array = json.optJSONArray("Items")

                val loaded = mutableListOf<Entry>()

                if (array != null) {
                    for (i in 0 until array.length()) {
                        val obj = array.getJSONObject(i)

                        val genres = obj.optJSONArray("Genres")
                        var documentary = false

                        if (genres != null) {
                            for (g in 0 until genres.length()) {
                                val genre = genres.optString(g)
                                if (
                                    genre.contains("document", true) ||
                                    genre.contains("dokument", true)
                                ) {
                                    documentary = true
                                }
                            }
                        }

                        if (parentId.isBlank()) {
                            val allowed = when (sectionIndex) {
                                1, 2 -> !documentary
                                3, 4 -> documentary
                                else -> true
                            }

                            if (!allowed) continue
                        }

                        loaded.add(
                            Entry(
                                obj.optString("Id"),
                                obj.optString("Name", "Ohne Titel"),
                                obj.optString("Type"),
                                obj.optInt("ProductionYear", 0),
                                obj.optString("ParentId")
                            )
                        )
                    }
                }

                                // EMBYFLOW_NEUHEITEN_DEDUP_V2
                // Gleicher Titel + Jahr + Typ = ein Eintrag.
                // Unterschiedliche Neuverfilmungen bleiben erhalten.

                fun normalizedTitle(value: String): String {
                    return java.text.Normalizer.normalize(
                        value.trim().lowercase(java.util.Locale.ROOT),
                        java.text.Normalizer.Form.NFKC
                    )
                        .replace(Regex("\\s+"), " ")
                        .replace(Regex("\\s*\\(\\d{4}\\)\\s*$"), "")
                        .trim()
                }

                val unique = loaded
                    .groupBy { item ->
                        val name = normalizedTitle(item.title)
                        val year = item.year
                        val type = item.type.lowercase(
                            java.util.Locale.ROOT
                        )

                        if (type in listOf("movie", "series") && year > 0) "$type|$name|$year" else "id:${item.id}"
                    }
                    .values
                    .map { versions ->
                        versions.first()
                    }

                runOnUiThread {
                    if (currentGeneration == generation) {
                        entries = unique
                        message = "${unique.size} Titel geladen"
                        screen.invalidate()
                    }
                }

                unique.forEach { item ->
                    if (currentGeneration != generation) return@forEach

                    try {
                        val imageUrl =
                            "$server/Items/${item.id}/Images/Primary?maxWidth=350"

                        val imageConnection =
                            URL(imageUrl).openConnection() as HttpURLConnection

                        imageConnection.connectTimeout = 8000
                        imageConnection.readTimeout = 10000
                        imageConnection.setRequestProperty(
                            "X-Emby-Token",
                            token
                        )

                        val bitmap = try {
                            if (imageConnection.responseCode == 200) {
                                BitmapFactory.decodeStream(
                                    imageConnection.inputStream
                                )
                            } else null
                        } finally {
                            imageConnection.disconnect()
                        }

                        if (bitmap != null) {
                            runOnUiThread {
                                if (currentGeneration == generation) {
                                    posters[item.id] = bitmap
                                    screen.invalidate()
                                }
                            }
                        }
                    } catch (_: Exception) {
                    }
                }

            } catch (e: Exception) {
                runOnUiThread {
                    if (currentGeneration == generation) {
                        message = "Fehler: ${e.message}"
                        screen.invalidate()
                    }
                }
            }
        }
    }

    // EMBYFLOW_DETAILS_V1
    private fun openSelected() {
        val item = entries.getOrNull(selected) ?: return
        when (item.type) {
            "Series", "Movie", "Episode" -> {
                startActivity(Intent(this, EmbyDetailsActivity::class.java).apply {
                    putExtra("item_id", item.id)
                    putExtra("item_type", item.type)
                    putExtra("item_title", item.title)
                })
            }
            "Season" -> {
                seasonId = item.id
                loadSection(seasonId)
            }
            else -> Toast.makeText(this, "Medientyp nicht unterstuetzt", Toast.LENGTH_SHORT).show()
        }
    }
    override fun onBackPressed() {
        when {
            seasonId.isNotBlank() -> {
                seasonId = ""
                loadSection(seriesId)
            }

            seriesId.isNotBlank() -> {
                seriesId = ""
                seriesTitle = ""
                loadSection()
            }

            else -> super.onBackPressed()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            onBackPressed()
            return true
        }

        val last = (entries.size - 1).coerceAtLeast(0)

        if (!focusPosters) {
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_UP -> {
                    sectionIndex = (sectionIndex - 1).coerceAtLeast(0)
                    seriesId = ""
                    seasonId = ""
                    loadSection()
                }

                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    sectionIndex =
                        (sectionIndex + 1).coerceAtMost(sections.lastIndex)
                    seriesId = ""
                    seasonId = ""
                    loadSection()
                }

                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    focusPosters = true
                }

                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER -> {
                    focusPosters = true
                }

                else -> return super.onKeyDown(keyCode, event)
            }
        } else {
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    selected = (selected + 1).coerceAtMost(last)
                }

                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    if (selected % 6 == 0) {
                        focusPosters = false
                    } else {
                        selected--
                    }
                }

                KeyEvent.KEYCODE_DPAD_UP -> {
                    selected = (selected - 6).coerceAtLeast(0)
                }

                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    selected = (selected + 6).coerceAtMost(last)
                }

                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER -> openSelected()

                else -> return super.onKeyDown(keyCode, event)
            }
        }

        screen.invalidate()
        return true
    }

    private inner class NeuheitenView : View(this@NeuheitenActivity) {

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        private fun label(
            canvas: Canvas,
            value: String,
            x: Float,
            y: Float,
            size: Float,
            color: Int,
            bold: Boolean = false
        ) {
            paint.color = color
            paint.textSize = size
            paint.typeface = if (bold) {
                android.graphics.Typeface.DEFAULT_BOLD
            } else {
                android.graphics.Typeface.DEFAULT
            }
            canvas.drawText(value, x, y, paint)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)

            canvas.drawColor(navy)
            canvas.save()
            canvas.scale(width / 1649f, height / 928f)

            paint.color = panel
            canvas.drawRect(0f, 0f, 267f, 928f, paint)

            paint.color = Color.rgb(44, 76, 101)
            canvas.drawRect(266f, 0f, 268f, 928f, paint)

            label(canvas, "EmbyFlow", 27f, 55f, 28f, white, true)

            sections.forEachIndexed { index, section ->
                val y = 176f + index * 83f
                val active = index == sectionIndex

                if (active && !focusPosters) {
                    paint.color = Color.rgb(20, 67, 91)
                    canvas.drawRoundRect(
                        RectF(17f, y - 35f, 248f, y + 18f),
                        7f, 7f, paint
                    )
                }

                label(
                    canvas,
                    if (active) "▸ $section" else section,
                    35f,
                    y,
                    23f,
                    if (active) cyan else muted
                )
            }

            label(canvas, title, 296f, 61f, 36f, white)
            label(canvas, message.take(85), 297f, 103f, 19f, muted)

            val pageSize = 12
            val page = selected / pageSize
            val first = page * pageSize

            for (slot in 0 until pageSize) {
                val index = first + slot
                val item = entries.getOrNull(index) ?: continue

                val col = slot % 6
                val row = slot / 6

                val x = 300f + col * 217f
                val y = 138f + row * 363f

                val selectedCard = focusPosters && index == selected

                paint.color = if (selectedCard) {
                    cyan
                } else {
                    Color.rgb(26, 57, 83)
                }

                canvas.drawRoundRect(
                    RectF(x - 4f, y - 4f, x + 184f, y + 260f),
                    5f, 5f, paint
                )

                val bitmap = posters[item.id]

                if (bitmap != null) {
                    canvas.drawBitmap(
                        bitmap,
                        null,
                        RectF(x, y, x + 180f, y + 256f),
                        Paint(
                            Paint.ANTI_ALIAS_FLAG or
                            Paint.FILTER_BITMAP_FLAG
                        )
                    )
                } else {
                    label(
                        canvas,
                        "Kein Poster",
                        x + 19f,
                        y + 130f,
                        17f,
                        muted
                    )
                }

                var shown = item.title
                paint.textSize = 18f

                while (
                    shown.length > 1 &&
                    paint.measureText(shown) > 193f
                ) {
                    shown = shown.dropLast(1)
                }

                if (shown != item.title) shown += "..."

                label(canvas, shown, x, y + 283f, 18f, white)

                val details = buildString {
                    if (item.year > 0) append("${item.year} · ")
                    append(
                        when (item.type) {
                            "Series" -> "Serie"
                            "Season" -> "Staffel"
                            "Episode" -> "Folge"
                            else -> "Film"
                        }
                    )
                }

                label(canvas, details, x, y + 316f, 17f, muted)
            }

            paint.color = Color.rgb(47, 78, 102)
            canvas.drawRect(0f, 873f, 1649f, 875f, paint)

            label(
                canvas,
                "ZURÜCK  Hauptmenü     OK  Öffnen     PFEILE  Navigation",
                30f,
                907f,
                19f,
                white
            )

            val pages =
                ((entries.size + pageSize - 1) / pageSize).coerceAtLeast(1)

            label(
                canvas,
                "Seite ${page + 1} / $pages",
                1470f,
                907f,
                19f,
                white
            )

            canvas.restore()
        }
    }
}