package de.embyflow.androidtv

import android.app.Activity
import android.media.MediaPlayer
import android.net.Uri
import android.view.View
import android.widget.FrameLayout
import android.widget.VideoView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

/** Only media returned by the authenticated Emby theme API; no local test paths. */
internal class DetailTheme(private val activity: Activity, private val root: FrameLayout, private val changed: () -> Unit) {
    private var video: VideoView? = null
    private var music: MediaPlayer? = null
    private var generation = 0
    var videoVisible = false
        private set
    fun stop() {
        generation++
        video?.setOnErrorListener(null); video?.setOnPreparedListener(null)
        video?.stopPlayback(); video?.let { root.removeView(it) }; video = null
        music?.setOnPreparedListener(null); music?.setOnErrorListener(null); music?.release(); music = null
        videoVisible = false; changed()
    }
    fun start(itemId: String, mode: String) {
        stop()
        if (mode == "off" || itemId.isBlank()) return
        val current = generation
        val prefs = activity.getSharedPreferences("embyflow", Activity.MODE_PRIVATE)
        val server = prefs.getString("server", "").orEmpty().trimEnd('/')
        val token = prefs.getString("token", "").orEmpty()
        val user = prefs.getString("userId", "").orEmpty()
        if (server.isBlank() || token.isBlank() || user.isBlank()) return
        thread {
            var address = ""
            try {
                val kind = if (mode == "video") "ThemeVideos" else "ThemeSongs"
                val connection = URL("$server/Items/${URLEncoder.encode(itemId, "UTF-8")}/$kind?UserId=$user&InheritFromParent=true").openConnection() as HttpURLConnection
                connection.connectTimeout = 6000; connection.readTimeout = 8000
                connection.setRequestProperty("X-Emby-Token", token)
                val json = try {
                    if (connection.responseCode !in 200..299) throw Exception("Theme unavailable")
                    JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
                } finally { connection.disconnect() }
                val id = json.optJSONArray("Items")?.optJSONObject(0)?.optString("Id").orEmpty()
                if (id.isNotBlank()) address = "$server/${if (mode == "video") "Videos" else "Audio"}/${URLEncoder.encode(id, "UTF-8")}/stream?static=true"
            } catch (_: Exception) { }
            val result = address
            activity.runOnUiThread {
                if (current != generation || activity.isFinishing || activity.isDestroyed || result.isBlank()) return@runOnUiThread
                if (mode == "video") {
                    val view = VideoView(activity); video = view
                    root.addView(view, 0, FrameLayout.LayoutParams(-1, -1, android.view.Gravity.CENTER))
                    view.isFocusable = false; view.isFocusableInTouchMode = false
                    view.setOnPreparedListener { player ->
                        if (video === view && current == generation) { player.isLooping = true; player.setVolume(.25f, .25f); view.start() }
                    }
                    view.setOnInfoListener { _, what, _ ->
                        if (video === view && what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) { videoVisible = true; changed() }
                        false
                    }
                    view.setOnErrorListener { _, _, _ -> if (video === view) stop(); true }
                    view.setVideoURI(Uri.parse(result), mapOf("X-Emby-Token" to token))
                } else {
                    val player = MediaPlayer(); music = player
                    try {
                        player.setDataSource(activity, Uri.parse(result), mapOf("X-Emby-Token" to token))
                        player.isLooping = true; player.setVolume(.25f, .25f)
                        player.setOnPreparedListener { if (music === player && current == generation) it.start() }
                        player.setOnErrorListener { _, _, _ -> if (music === player) stop(); true }
                        player.prepareAsync()
                    } catch (_: Exception) { stop() }
                }
            }
        }
    }
}
