package de.embyflow.androidtv

import android.app.Activity
import android.app.AlertDialog
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.text.InputType
import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.Toast

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.RectF
import android.content.Intent
import android.net.Uri
import java.net.URLEncoder
class MainActivity : Activity() {

    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (event.keyCode == android.view.KeyEvent.KEYCODE_BACK ||
            event.keyCode == android.view.KeyEvent.KEYCODE_ESCAPE) {

            if (event.action == android.view.KeyEvent.ACTION_UP) { if (seriesBack()) return true
                if (resumeGridActive || categoryGridActive) {
                    resumeGridActive = false
            categoryGridActive = false
                    mediaSelected = 0
                    fetchMedia("Movie")
                    screen.invalidate()
                } else {
                    finish()
                }
            }

            return true
        }

        return super.dispatchKeyEvent(event)
    }


    override fun onBackPressed() { if (seriesBack()) return
        if (resumeGridActive || categoryGridActive) {
            resumeGridActive = false
            categoryGridActive = false
            mediaSelected = 0
            fetchMedia("Movie")
            screen.invalidate()
        } else {
            finish()
        }
    }


    private lateinit var screen: EmbyScreen

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        screen = EmbyScreen()
        setContentView(screen)
        loadDailySlideshow()
        scheduleDailySlideRefresh()

        // EmbyFlow: Mediathek beim Start automatisch laden.
        screen.postDelayed({
            val startPrefs = getSharedPreferences(
                "embyflow",
                Context.MODE_PRIVATE
            )

            val hasServer = !startPrefs.getString(
                "server", ""
            ).isNullOrBlank()

            val hasToken = !startPrefs.getString(
                "token", ""
            ).isNullOrBlank()

            val hasUser = !startPrefs.getString(
                "userId", ""
            ).isNullOrBlank()

            if (hasServer && hasToken && hasUser) {
                fetchMedia("Movie")
            }
        }, 700L)
    }


    private fun openEmbySettings() {

        val prefs = getSharedPreferences(
            "embyflow",
            Context.MODE_PRIVATE
        )

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(35, 20, 35, 10)
        }

        val serverInput = EditText(this).apply {
            hint = "Server-Adresse (http://...:8096)"
            setSingleLine(true)
            setText(prefs.getString("server", ""))
            textSize = 19f
        }

        val userInput = EditText(this).apply {
            hint = "Benutzername"
            setSingleLine(true)
            setText(prefs.getString("username", ""))
            textSize = 19f
        }

        val passwordInput = EditText(this).apply {
            hint = "Passwort"
            inputType =
                InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_VARIATION_PASSWORD
            textSize = 19f
        }

        layout.addView(serverInput)
        layout.addView(userInput)
        layout.addView(passwordInput)

        val dialog = AlertDialog.Builder(this)
            .setTitle("EmbyFlow - Serververbindung")
            .setView(layout)
            .setNegativeButton("Abbrechen", null)
            .setPositiveButton("Verbinden", null)
            .create()

        dialog.setOnShowListener {

            dialog.getButton(
                AlertDialog.BUTTON_POSITIVE
            ).setOnClickListener {

                val server = serverInput.text.toString()
                    .trim().trimEnd('/')

                val username = userInput.text.toString().trim()
                val password = passwordInput.text.toString()

                if (
                    !(server.startsWith("http://") ||
                      server.startsWith("https://")) ||
                    username.isBlank()
                ) {
                    Toast.makeText(
                        this,
                        "Bitte Server-Adresse und Benutzername prüfen.",
                        Toast.LENGTH_LONG
                    ).show()
                    return@setOnClickListener
                }

                dialog.getButton(
                    AlertDialog.BUTTON_POSITIVE
                ).isEnabled = false

                thread {
                    try {

                        val connection = URL(
                            "$server/Users/AuthenticateByName"
                        ).openConnection() as HttpURLConnection

                        connection.requestMethod = "POST"
                        connection.connectTimeout = 10000
                        connection.readTimeout = 10000
                        connection.doOutput = true

                        connection.setRequestProperty(
                            "Content-Type",
                            "application/json"
                        )

                        connection.setRequestProperty(
                            "X-Emby-Authorization",
                            """MediaBrowser Client="EmbyFlowAndroid", Device="AndroidTV", DeviceId="embyflowandroid", Version="0.3.0" """
                        )

                        val payload = JSONObject()
                        payload.put("Username", username)
                        payload.put("Pw", password)

                        connection.outputStream.use {
                            it.write(
                                payload.toString()
                                    .toByteArray(Charsets.UTF_8)
                            )
                        }

                        val responseCode = connection.responseCode

                        if (responseCode != 200) {
                            connection.disconnect()
                            throw Exception("HTTP $responseCode")
                        }

                        val result =
                            connection.inputStream.bufferedReader().use {
                                JSONObject(it.readText())
                            }

                        connection.disconnect()

                        val token = result.getString("AccessToken")
                        val userId =
                            result.getJSONObject("User").getString("Id")

                        prefs.edit()
                            .putString("server", server)
                            .putString("username", username)
                            .putString("token", token)
                            .putString("userId", userId)
                            .apply()

                        runOnUiThread {
                            dialog.dismiss()

                            Toast.makeText(
                                this,
                                "Emby erfolgreich verbunden!",
                                Toast.LENGTH_LONG
                            ).show()

                            screen.invalidate()
                        }

                    } catch (e: Exception) {

                        runOnUiThread {
                            dialog.getButton(
                                AlertDialog.BUTTON_POSITIVE
                            ).isEnabled = true

                            Toast.makeText(
                                this,
                                "Verbindung fehlgeschlagen: ${e.message}",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                }
            }
        }

        dialog.show()
    }






    // EMBYFLOW_MEDIA_TEST_V2

    private data class MediaEntry(
        val id: String,
        val title: String,
        val type: String,
        val overview: String = ""
    )

    // EMBYFLOW_RESUME_GRID_V31
    private var resumeGridActive = false

    // EMBYFLOW_CATEGORY_V31
    private var categoryGridActive = false
    private var categoryGridTitle = "Filme"
    private val resumeCards = mutableMapOf<String, ResumeCard>()
    private var mediaEntries = listOf<MediaEntry>()
    private val mediaPosters = mutableMapOf<String, Bitmap>()
    private var mediaSelected = 0
    private var mediaMessage = "Mediathek noch nicht geladen"
    private var mediaCategory = "Movie"

    // EMBYFLOW_SERIES_NAV_FIXED
    private var seriesLevel = 0
    private var selectedSeriesId = ""
    private var selectedSeriesTitle = ""
    private var selectedSeasonId = ""
    private var selectedSeasonTitle = ""
    private var seriesRootSection = "Serien"

    private fun seriesBack(): Boolean {
        when (seriesLevel) {
            2 -> {
                seriesLevel = 1
                fetchMedia(
                    "Season",
                    section = "Staffeln: $selectedSeriesTitle",
                    parentId = selectedSeriesId
                )
                return true
            }

            1 -> {
                seriesLevel = 0
                fetchMedia(
                    "Series",
                    section = seriesRootSection
                )
                return true
            }
        }

        return false
    }
    // EMBYFLOW_SLIDESHOW_TIMER_V2
    private var slideshowStartedAt = 0L
    private var slideshowPosition = 0
    private var slideshowHomeActive = false

    private val slideshowTick = Runnable {
        if (slideshowHomeActive) {
            screen.invalidate()
        }
    }

    private fun resetSlideshowTimer() {
        slideshowHomeActive = false
        slideshowStartedAt = 0L
        slideshowPosition = 0

        if (::screen.isInitialized) {
            screen.removeCallbacks(slideshowTick)
        }
    }

    private fun currentSlideshowPosition(): Int {
        val now = android.os.SystemClock.uptimeMillis()

        if (!slideshowHomeActive) {
            slideshowHomeActive = true
            slideshowStartedAt = now
            slideshowPosition = 0

            screen.removeCallbacks(slideshowTick)
            screen.postDelayed(slideshowTick, 20000L)

        } else if (now - slideshowStartedAt >= 20000L) {
            slideshowPosition++
            slideshowStartedAt = now

            screen.removeCallbacks(slideshowTick)
            screen.postDelayed(slideshowTick, 20000L)
        }

        return slideshowPosition
    }
    // EMBYFLOW_DAILY_SLIDESHOW_V3

    private var dailySlideEntries = listOf<MediaEntry>()
    private val dailySlidePosters = mutableMapOf<String, Bitmap>()
    private var dailySlideGeneration = 0

    private fun dailySlideDate(): String {
        return java.text.SimpleDateFormat(
            "yyyyMMdd",
            java.util.Locale.GERMANY
        ).format(java.util.Date())
    }

    private fun scheduleDailySlideRefresh() {
        val now = java.util.Calendar.getInstance(
            java.util.TimeZone.getTimeZone("Europe/Berlin")
        )

        val midnight = now.clone() as java.util.Calendar
        midnight.add(java.util.Calendar.DAY_OF_MONTH, 1)
        midnight.set(java.util.Calendar.HOUR_OF_DAY, 0)
        midnight.set(java.util.Calendar.MINUTE, 0)
        midnight.set(java.util.Calendar.SECOND, 0)
        midnight.set(java.util.Calendar.MILLISECOND, 0)

        val delay = (midnight.timeInMillis - now.timeInMillis)
            .coerceAtLeast(1000L)

        screen.postDelayed({
            loadDailySlideshow()
            scheduleDailySlideRefresh()
        }, delay)
    }

    private fun loadDailySlideshow() {
        val prefs = getSharedPreferences(
            "embyflow",
            Context.MODE_PRIVATE
        )

        val server = prefs.getString("server", "")
            .orEmpty().trimEnd('/')

        val token = prefs.getString("token", "").orEmpty()
        val userId = prefs.getString("userId", "").orEmpty()

        if (server.isBlank() || token.isBlank() || userId.isBlank()) {
            return
        }

        val date = dailySlideDate()
        val savedDate = prefs.getString(
            "daily_slideshow_date_v3", ""
        ).orEmpty()

        val savedItems = prefs.getString(
            "daily_slideshow_items_v3", ""
        ).orEmpty()

        val generation = ++dailySlideGeneration

        thread {
            try {
                val jsonText: String

                if (savedDate == date && savedItems.isNotBlank()) {
                    jsonText = savedItems
                } else {
                    val address =
                        "$server/Users/$userId/Items" +
                        "?Recursive=true" +
                        "&IncludeItemTypes=Movie,Series" +
                        "&SortBy=DateCreated" +
                        "&SortOrder=Descending" +
                        "&Fields=Overview,DateCreated" +
                        "&Limit=20"

                    val connection =
                        URL(address).openConnection() as HttpURLConnection

                    connection.connectTimeout = 10000
                    connection.readTimeout = 15000
                    connection.setRequestProperty(
                        "X-Emby-Token",
                        token
                    )

                    jsonText = try {
                        if (connection.responseCode != 200) {
                            throw Exception(
                                "Emby HTTP ${connection.responseCode}"
                            )
                        }

                        connection.inputStream.bufferedReader().use {
                            it.readText()
                        }
                    } finally {
                        connection.disconnect()
                    }

                    prefs.edit()
                        .putString("daily_slideshow_date_v3", date)
                        .putString("daily_slideshow_items_v3", jsonText)
                        .apply()
                }

                val items = JSONObject(jsonText).getJSONArray("Items")

                val entries = (0 until items.length()).map { index ->
                    val obj = items.getJSONObject(index)

                    MediaEntry(
                        obj.getString("Id"),
                        obj.optString("Name", "Ohne Titel"),
                        obj.optString("Type", "Movie"),
                        obj.optString("Overview", "")
                    )
                }

                runOnUiThread {
                    if (generation == dailySlideGeneration) {
                        dailySlideEntries = entries
                        dailySlidePosters.clear()
                        resetSlideshowTimer()
                        screen.invalidate()
                    }
                }

                entries.forEach { item ->
                    if (generation != dailySlideGeneration) {
                        return@forEach
                    }

                    try {
                        val imageUrl =
                            "$server/Items/${item.id}/Images/Primary" +
                            "?maxWidth=640"

                        val connection =
                            URL(imageUrl).openConnection() as HttpURLConnection

                        connection.connectTimeout = 8000
                        connection.readTimeout = 10000
                        connection.setRequestProperty(
                            "X-Emby-Token",
                            token
                        )

                        val bitmap = try {
                            if (connection.responseCode == 200) {
                                BitmapFactory.decodeStream(
                                    connection.inputStream
                                )
                            } else {
                                null
                            }
                        } finally {
                            connection.disconnect()
                        }

                        if (bitmap != null) {
                            runOnUiThread {
                                if (generation == dailySlideGeneration) {
                                    dailySlidePosters[item.id] = bitmap
                                    screen.invalidate()
                                }
                            }
                        }
                    } catch (_: Exception) {
                        // Fehlendes Bild ueberspringen.
                    }
                }

            } catch (e: Exception) {
                android.util.Log.e(
                    "EmbyFlowSlideshow",
                    "Taegliche Slideshow konnte nicht geladen werden",
                    e
                )
            }
        }
    }
    private var mediaLoadGeneration = 0

    private fun fetchMedia(category: String, resume: Boolean = false, section: String = "", parentId: String = "") {
        // EMBYFLOW_RESUME_V1
        val prefs = getSharedPreferences("embyflow", Context.MODE_PRIVATE)

        val server = prefs.getString("server", "")
            .orEmpty().trimEnd('/')

        val token = prefs.getString("token", "").orEmpty()
        val userId = prefs.getString("userId", "").orEmpty()

        if (server.isBlank() || token.isBlank() || userId.isBlank()) {
            Toast.makeText(
                this,
                "Bitte zuerst mit Emby verbinden.",
                Toast.LENGTH_LONG
            ).show()
            openEmbySettings()
            return
        }

        val requestGeneration = ++mediaLoadGeneration
        // EMBYFLOW_CATEGORIES_FIX_V2
        mediaCategory = category

        if (resume) {
            resumeGridActive = true
            categoryGridActive = false
        } else if (section.isNotBlank()) {
            resumeGridActive = false
            categoryGridActive = true
            categoryGridTitle = section
        } else {
            resumeGridActive = false
            categoryGridActive = false
        }
        mediaMessage = if (resume) {
            "Lade Weiterschauen ..."
        } else {
            "Lade Mediathek ..."
        }
        favoriteVariants = emptyMap()
        mediaEntries = emptyList()
        mediaPosters.clear()
        mediaSelected = 0
        screen.invalidate()

        thread {
            try {
                val address = if (resume) {
                    "$server/Users/$userId/Items/Resume" +
                        "?Recursive=true" +
                        "&IncludeItemTypes=Movie,Episode" +
                        "&Fields=Overview" +
                        "&Limit=60"
                } else {
                    val params = mutableListOf(
                        "Recursive=true",
                        "IncludeItemTypes=$category",
                        "Fields=Overview,ProductionYear",
                        "SortBy=SortName",
                        "Limit=60"
                    )

                    if (parentId.isNotBlank()) {
                        params.remove("Recursive=true")
                        params.add("Recursive=false")
                        params.add("ParentId=$parentId")
                    }
                                        // EMBYFLOW_NEUHEITEN_GENRE_V1
                    if (section == "Neu: Dokus" ||
                        section == "Neu: Doku-Serien") {
                        params.add("Genres=Documentary")
                    }

                    if (section == "Neu: Filme" ||
                        section == "Neu: Serien") {
                        params.add("ExcludeGenres=Documentary")
                    }
                    if (section == "Favoriten") {
                        params.add("IsFavorite=true")
                    }

                    if (section == "Neu hinzugefügt" || section.startsWith("Neu: ")) {
                        params.remove("SortBy=SortName")
                        params.add("SortBy=DateCreated")
                        params.add("SortOrder=Descending")
                    }

                    if (parentId.isBlank() && section.isNotBlank() && (section !in listOf("Filme", "Serien", "Favoriten", "Neu hinzugefügt") && !section.startsWith("Neu: "))
                    ) {
                        val viewsUrl = "$server/Users/$userId/Views"
                        val viewsConnection =
                            URL(viewsUrl).openConnection() as HttpURLConnection

                        try {
                            viewsConnection.connectTimeout = 8000
                            viewsConnection.readTimeout = 8000
                            viewsConnection.setRequestProperty(
                                "X-Emby-Token", token
                            )

                            if (viewsConnection.responseCode == 200) {
                                val views = JSONObject(
                                    viewsConnection.inputStream
                                        .bufferedReader()
                                        .use { it.readText() }
                                ).optJSONArray("Items")

                                var libraryId = ""

                                if (views != null) {
                                    for (i in 0 until views.length()) {
                                        val view = views.optJSONObject(i)
                                            ?: continue

                                        if (view.optString("Name")
                                                .trim()
                                                .equals(section, true)
                                        ) {
                                            libraryId = view.optString("Id")
                                            break
                                        }
                                    }
                                }

                                if (libraryId.isBlank()) {
                                    throw Exception(
                                        "Bibliothek '$section' nicht gefunden"
                                    )
                                }

                                params.add("ParentId=$libraryId")
                            } else {
                                throw Exception(
                                    "Bibliotheken konnten nicht geladen werden"
                                )
                            }
                        } finally {
                            viewsConnection.disconnect()
                        }
                    }

                    "$server/Users/$userId/Items?" +
                        params.joinToString("&")
                }

                val connection =
                    URL(address).openConnection() as HttpURLConnection

                connection.connectTimeout = 10000
                connection.readTimeout = 15000
                connection.setRequestProperty("X-Emby-Token", token)

                val response = try {
                    val status = connection.responseCode

                    if (status != 200) {
                        throw Exception("Emby HTTP $status")
                    }

                    connection.inputStream.bufferedReader().use {
                        it.readText()
                    }
                } finally {
                    connection.disconnect()
                }

                val responseObject = JSONObject(response)
                val items = responseObject.getJSONArray("Items")
                val totalCount = responseObject.optInt(
                    "TotalRecordCount",
                    items.length()
                )

                val loaded = (0 until items.length()).map { index ->
                    val obj = items.getJSONObject(index)

                    MediaEntry(
                        obj.getString("Id"),
                        obj.optString("Name", "Ohne Titel"),
                        obj.optString("Type", category),
                        obj.optString("Overview", "")
                    )
                }

                val cardData = (0 until items.length()).associate { index ->
                    val obj = items.getJSONObject(index)
                    val id = obj.getString("Id")
                    val userData = obj.optJSONObject("UserData")

                    val ticks = userData?.optLong(
                        "PlaybackPositionTicks", 0L
                    ) ?: 0L

                    val duration = obj.optLong("RunTimeTicks", 0L)

                    val reported = userData?.optDouble(
                        "PlayedPercentage", -1.0
                    ) ?: -1.0

                    val percentage = (
                        if (reported >= 0.0) {
                            reported.toInt()
                        } else if (duration > 0L) {
                            (ticks.toDouble() * 100.0 / duration).toInt()
                        } else {
                            0
                        }
                    ).coerceIn(0, 100)

                    val type = obj.optString("Type", "Movie")
                    val season = obj.optInt("ParentIndexNumber", 0)
                    val episode = obj.optInt("IndexNumber", 0)

                    id to ResumeCard(
                        id = id,
                        title = obj.optString("Name", "Ohne Titel"),
                        type = type,
                        year = obj.optInt("ProductionYear", 0),
                        progress = percentage,
                        episode = if (type == "Episode") {
                            "S%02dE%02d".format(season, episode)
                        } else {
                            ""
                        }
                    )
                }

                val groupedFavorites = if (section == "Favoriten") MediaVariants.group(
                    (0 until items.length()).map { items.getJSONObject(it) }
                ) else emptyList()
                val variantsById = groupedFavorites.associate { group -> group.first().optString("Id") to group }
                val uniqueItems = if (section == "Favoriten") {
                    loaded.filter { variantsById.containsKey(it.id) }.distinctBy { it.id }
                } else if (resume) {
                    loaded.distinctBy { entry ->
                        if (entry.type == "Episode") {
                            "episode:${entry.id}"
                        } else {
                            val normalized = entry.title.lowercase()
                                .replace(Regex("[^a-z0-9]"), "")

                            val year = cardData[entry.id]?.year ?: 0

                            "movie:$normalized:$year"
                        }
                    }
                } else {
                    loaded
                }

                runOnUiThread {
                    if (requestGeneration != mediaLoadGeneration || isFinishing || isDestroyed) return@runOnUiThread
                    favoriteVariants = variantsById
                    mediaEntries = uniqueItems
                    resumeCards.clear()
                    resumeCards.putAll(cardData)
                    mediaMessage = if (resume) {
                        if (loaded.isEmpty()) {
                            "Keine angefangenen Filme oder Serien"
                        } else {
                            "$totalCount Titel zum Weiterschauen"
                        }
                    } else if (section == "Favoriten") {
                        "${uniqueItems.size} Favoriten · ${loaded.size} geladene Versionen"
                    } else {
                        "$totalCount Medien insgesamt"
                    }
                    screen.invalidate()
                }

                                // EMBYFLOW_POSTER_FIX_V1
                // Poster fuer alle geladenen Medien abrufen.
                (if (resume || section == "Favoriten") uniqueItems else loaded).forEach { item ->
                    try {
                        val imageUrl =
                            "$server/Items/${item.id}/Images/Primary?maxWidth=320"

                        val imageConnection =
                            URL(imageUrl).openConnection() as HttpURLConnection

                        imageConnection.connectTimeout = 8000
                        imageConnection.readTimeout = 10000
                        imageConnection.setRequestProperty(
                            "X-Emby-Token",
                            token
                        )

                        val bitmap = try {
                            if (imageConnection.responseCode == 200) {
                                BitmapFactory.decodeStream(
                                    imageConnection.inputStream
                                )
                            } else {
                                null
                            }
                        } finally {
                            imageConnection.disconnect()
                        }

                        if (bitmap != null) {
                            runOnUiThread {
                    if (requestGeneration != mediaLoadGeneration || isFinishing || isDestroyed) return@runOnUiThread
                                mediaPosters[item.id] = bitmap
                                screen.invalidate()
                            }
                        }
                    } catch (_: Exception) {
                    }
                }

            } catch (e: Exception) {
                runOnUiThread {
                    if (requestGeneration != mediaLoadGeneration || isFinishing || isDestroyed) return@runOnUiThread
                    mediaMessage = "Fehler: ${e.message}"
                    screen.invalidate()
                }
            }
        }
    }

    private var favoriteVariants = emptyMap<String, List<JSONObject>>()

    private fun playSelectedMedia() {
        val item = mediaEntries.getOrNull(mediaSelected)

        if (item == null) {
            Toast.makeText(
                this,
                "Bitte zuerst einen Film auswählen.",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        if (item.type in listOf("Movie", "Series", "Episode")) {
            val open: (String, String, String) -> Unit = { id, type, title ->
                startActivity(Intent(this, EmbyDetailsActivity::class.java).apply {
                    putExtra("item_id", id); putExtra("item_type", type); putExtra("item_title", title)
                })
            }
            val variants = favoriteVariants[item.id].orEmpty()
            if (variants.size > 1) QualityChooser.show(this, item.title, variants) { chosen ->
                open(chosen.optString("Id"), chosen.optString("Type", item.type), chosen.optString("Name", item.title))
            } else open(item.id, item.type, item.title)
            return
        }
        if (item.type == "Series") {
            seriesRootSection = if (
                categoryGridTitle.startsWith("Serien") &&
                !categoryGridTitle.startsWith("Staffeln:")
            ) {
                categoryGridTitle
            } else {
                "Serien"
            }

            selectedSeriesId = item.id
            selectedSeriesTitle = item.title
            seriesLevel = 1

            fetchMedia(
                "Season",
                section = "Staffeln: $selectedSeriesTitle",
                parentId = selectedSeriesId
            )

            return
        }

        if (item.type == "Season") {
            selectedSeasonId = item.id
            selectedSeasonTitle = item.title
            seriesLevel = 2

            fetchMedia(
                "Episode",
                section = "Folgen: $selectedSeasonTitle",
                parentId = selectedSeasonId
            )

            return
        }

        val prefs = getSharedPreferences("embyflow", Context.MODE_PRIVATE)

        val server = prefs.getString("server", "")
            .orEmpty().trimEnd('/')

        val token = prefs.getString("token", "").orEmpty()

        if (server.isBlank() || token.isBlank()) return

        val encodedToken = URLEncoder.encode(token, "UTF-8")

        val address = "$server/Videos/${item.id}/stream" +
            "?static=true&api_key=$encodedToken"

        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(
                    Uri.parse(address),
                    "video/*"
                )
            }

            // EMBYFLOW_MEDIA3_LAUNCH_V32
            startActivity(
                Intent(this, EmbyPlayerActivity::class.java).apply {
                    putExtra("stream_url", address)
                    putExtra("item_id", item.id)
                }
            )

        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Player konnte nicht gestartet werden: ${e.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        android.util.Log.d(
            "EmbyFlowKeys",
            "Taste empfangen: $keyCode"
        )

        if (screen.handleKey(keyCode)) {
            android.util.Log.d(
                "EmbyFlowKeys",
                "Taste verarbeitet: $keyCode"
            )
            return true
        }

        return super.onKeyDown(keyCode, event)
    }

    private inner class EmbyScreen : View(this@MainActivity) {

        private val p = Paint(Paint.ANTI_ALIAS_FLAG)

        private val navy = Color.rgb(12, 24, 39)
        private val cyan = Color.rgb(21, 185, 255)
        private val pink = Color.rgb(197, 74, 122)
        private val white = Color.rgb(225, 231, 240)
        private val muted = Color.rgb(155, 167, 184)
        private val selection = Color.rgb(15, 81, 99)
        private val panel = Color.rgb(23, 58, 94)

        private val menu = listOf(
            "Start",
            "Weiterschauen",
            "Neu hinzugefügt",
            "Filme",
            "  Filme 3D",
            "  Filme 4K",
            "  Filme O-Ton",
            "Hörbücher",
            "Konzerte Musik",
            "Serien",
            "  Serien 4K",
            "  Serien Anime",
            "  Serien Doku Reality",
            "  Serien O-Ton",
            "Favoriten",
            "Suche",
            "Updates",
            "Info / Einstellungen"
        )

        private var selected = 0
        private var focusArea = 0
        private var actionIndex = 0

        private val actions = listOf("Abspielen", "Details")

        private fun rectangle(
            c: Canvas,
            x: Float,
            y: Float,
            w: Float,
            h: Float,
            color: Int,
            radius: Float = 0f
        ) {
            p.color = color
            p.style = Paint.Style.FILL
            c.drawRoundRect(
                x, y, x + w, y + h,
                radius, radius, p
            )
        }

        private fun text(
            c: Canvas,
            value: String,
            x: Float,
            y: Float,
            size: Float,
            color: Int = white,
            bold: Boolean = false
        ) {
            p.color = color
            p.style = Paint.Style.FILL
            p.textSize = size
            p.typeface = if (bold) {
                Typeface.create("sans-serif", Typeface.BOLD)
            } else {
                Typeface.create("sans-serif", Typeface.NORMAL)
            }
            c.drawText(value, x, y, p)
        }

        private fun line(
            c: Canvas,
            x1: Float,
            y1: Float,
            x2: Float,
            y2: Float,
            color: Int
        ) {
            p.color = color
            p.strokeWidth = 2f
            c.drawLine(x1, y1, x2, y2, p)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)

            canvas.drawColor(navy)

            val sx = width / 1649f
            val sy = height / 928f

            canvas.save()
            canvas.scale(sx, sy)

            if (resumeGridActive) { resetSlideshowTimer(); val cards = mediaEntries.map { entry ->
                    resumeCards[entry.id] ?: ResumeCard(
                        entry.id,
                        entry.title,
                        entry.type,
                        0,
                        0,
                        ""
                    )
                }

                ResumeGridRenderer.draw(
                    canvas,
                    cards,
                    mediaPosters,
                    mediaSelected,
                    mediaMessage
                )

                canvas.restore()
                return
            }

                        if (categoryGridActive) { resetSlideshowTimer(); drawCategoryGrid(canvas)
                canvas.restore()
                return
            }

            drawSidebar(canvas)
            drawHero(canvas)
            drawMedia(canvas)
            drawFooter(canvas)

            canvas.restore()
        }
        private fun drawCategoryGrid(c: Canvas) {
            val heading = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 42f
                typeface = Typeface.DEFAULT_BOLD
            }

            val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 21f
            }

            val info = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(155, 167, 184)
                textSize = 20f
            }

            c.drawText(categoryGridTitle, 65f, 85f, heading)
            c.drawText(mediaMessage.take(95), 65f, 125f, info)

            val columns = 5
            val pageSize = 10
            val page = mediaSelected / pageSize
            val first = page * pageSize

            for (slot in 0 until pageSize) {
                val index = first + slot
                val item = mediaEntries.getOrNull(index) ?: continue

                val col = slot % columns
                val row = slot / columns

                val x = 65f + col * 315f
                val y = 170f + row * 350f

                val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = if (index == mediaSelected) {
                        Color.rgb(21, 185, 255)
                    } else {
                        Color.rgb(23, 58, 94)
                    }
                }

                c.drawRoundRect(
                    RectF(x - 6f, y - 6f, x + 246f, y + 286f),
                    8f, 8f, framePaint
                )

                val poster = mediaPosters[item.id]

                if (poster != null) {
                    c.drawBitmap(
                        poster,
                        null,
                        RectF(x, y, x + 240f, y + 280f),
                        Paint(
                            Paint.ANTI_ALIAS_FLAG or
                            Paint.FILTER_BITMAP_FLAG
                        )
                    )
                } else {
                    c.drawText("Kein Poster", x + 20f, y + 140f, info)
                }

                // Two title lines, including grouped favorites; never spill into the next card.
                val words = item.title.trim().split(Regex("\\s+"))
                val titleRows = mutableListOf<String>()
                var currentTitle = ""
                for (word in words) {
                    val next = if (currentTitle.isEmpty()) word else "$currentTitle $word"
                    if (label.measureText(next) > 275f && currentTitle.isNotEmpty()) {
                        titleRows.add(currentTitle); currentTitle = word
                    } else currentTitle = next
                }
                if (currentTitle.isNotEmpty()) titleRows.add(currentTitle)
                titleRows.take(2).forEachIndexed { titleIndex, rowTitle ->
                    var shown = rowTitle
                    if (label.measureText(shown) > 275f || (titleIndex == 1 && titleRows.size > 2)) {
                        shown = shown.take(label.breakText(shown, true, 275f - label.measureText("…"), null)) + "…"
                    }
                    c.drawText(shown, x, y + 305f + titleIndex * 26f, label)
                }
            }

            val pages = (
                (mediaEntries.size + pageSize - 1) / pageSize
            ).coerceAtLeast(1)

            c.drawText(
                "Seite ${page + 1} / $pages",
                65f, 910f, info
            )

            c.drawText(
                "OK: Öffnen     Pfeile: Navigation     Zurück: Hauptmenü",
                530f, 910f, info
            )
        }
        private fun drawSidebar(c: Canvas) {

            text(c, "EMBY", 41f, 111f, 23f, cyan)
            text(c, "FLOW", 41f, 142f, 23f, pink)

            text(c, "NAVIGATION", 41f, 174f, 12f, muted)

            val startY = 214f
            val spacing = 29f

            menu.forEachIndexed { index, item ->

                val y = startY + index * spacing

                if (index == selected && focusArea == 0) {
                    rectangle(
                        c, 38f, y - 21f,
                        170f, 26f, selection, 5f
                    )
                }

                if (index == 3 || index == 9) {
                    text(c, "▾", 28f, y, 17f, Color.YELLOW)
                }

                text(
                    c,
                    item,
                    54f,
                    y,
                    16f,
                    if (index == selected && focusArea == 0)
                        Color.WHITE else white
                )
            }

            text(c, "Cyan / Pink", 41f, 755f, 12f, muted)
        }

        private fun drawHero(c: Canvas) {

            text(c, "EmbyFlowE2", 249f, 56f, 28f)

            text(
                c,
                "EmbyFlow",
                249f,
                145f,
                46f
            )

            text(
                c,
                "Deine Mediathek",
                252f,
                188f,
                22f,
                muted
            )

            text(
                c,
                "Verbinde deinen Emby-Server,",
                252f,
                232f,
                21f
            )

            text(
                c,
                "um Filme und Serien anzuzeigen.",
                252f,
                257f,
                21f
            )

            actions.forEachIndexed { index, label ->

                val x = if (index == 0) 252f else 462f
                val w = if (index == 0) 190f else 147f

                val color =
                    if (focusArea == 1 && actionIndex == index)
                        selection else panel

                rectangle(c, x, 280f, w, 50f, color)

                text(
                    c,
                    label,
                    x + 28f,
                    313f,
                    22f
                )
            }

            rectangle(
                c,
                993f, 60f,
                652f, 288f,
                panel
            )

            text(
                c,
                "EMBYFLOW",
                1150f,
                193f,
                38f,
                cyan,
                true
            )

            text(
                c,
                "Android TV",
                1200f,
                232f,
                22f,
                white
            )
        }

        private fun drawMedia(c: Canvas) {

            val headings = listOf(
                "Weiter schauen",
                "Entdecken",
                "Empfohlen für dich"
            )

            val starts = listOf(250f, 730f, 1212f)

            headings.forEachIndexed { section, heading ->

                val x = starts[section]

                text(c, heading, x, 379f, 25f)

                for (i in 0..1) {

                    val index = section * 2 + i
                    val posterX = x + i * 225f
                    val item = mediaEntries.getOrNull(index)
                    val bitmap = item?.let { mediaPosters[it.id] }

                    val background =
                        if (index == mediaSelected && mediaEntries.isNotEmpty())
                            selection
                        else
                            panel

                    rectangle(
                        c,
                        posterX,
                        404f,
                        190f,
                        270f,
                        background,
                        5f
                    )

                    if (bitmap != null) {
                        p.color = Color.WHITE

                        c.drawBitmap(
                            bitmap,
                            null,
                            RectF(
                                posterX,
                                404f,
                                posterX + 190f,
                                674f
                            ),
                            p
                        )
                    } else {
                        text(
                            c,
                            if (item == null) "Kein Poster" else "Lade Poster",
                            posterX + 15f,
                            540f,
                            18f,
                            muted
                        )
                    }

                    val title = item?.title ?: "Noch keine Medien"

                    text(
                        c,
                        title.take(23),
                        posterX,
                        700f,
                        16f,
                        if (index == mediaSelected) cyan else muted
                    )
                }

                line(
                    c,
                    x,
                    758f,
                    x + 420f,
                    758f,
                    cyan
                )
            }
        }
        private fun drawFooter(c: Canvas) { val stableSlideshowIndex = currentSlideshowPosition()

            text(c, "Server", 270f, 792f, 21f, cyan)

                        val connected = getSharedPreferences(
                "embyflow",
                Context.MODE_PRIVATE
            ).getString("token", "").orEmpty().isNotBlank()

            text(
                c,
                if (connected) {
                    val name = getSharedPreferences(
                        "embyflow",
                        Context.MODE_PRIVATE
                    ).getString("username", "").orEmpty()

                    if (name.isNotBlank()) {
                        "Verbunden - $name"
                    } else {
                        "Verbunden"
                    }
                } else {
                    "Nicht verbunden"
                },
                270f,
                824f,
                17f,
                if (connected) Color.GREEN else white
            )

                            // EMBYFLOW_SLIDESHOW_RESTORED
                run {
                    val slides = dailySlideEntries.mapNotNull { entry ->
                        dailySlidePosters[entry.id]
                    }

                    if (slides.isNotEmpty()) {
                        val slideIndex = stableSlideshowIndex % slides.size

                        val bitmap = slides[slideIndex]


                        val target = android.graphics.RectF(
                            995f, 60f, 1645f, 348f
                        )

                        val sourceWidth = bitmap.width
                        val sourceHeight = bitmap.height

                        val sourceRatio =
                            sourceWidth.toFloat() / sourceHeight.toFloat()

                        val targetRatio =
                            target.width() / target.height()

                        val source = if (sourceRatio > targetRatio) {
                            val cropWidth =
                                (sourceHeight * targetRatio).toInt()

                            val left = (sourceWidth - cropWidth) / 2

                            android.graphics.Rect(
                                left,
                                0,
                                left + cropWidth,
                                sourceHeight
                            )
                        } else {
                            val cropHeight =
                                (sourceWidth / targetRatio).toInt()

                            val top = (sourceHeight - cropHeight) / 2

                            android.graphics.Rect(
                                0,
                                top,
                                sourceWidth,
                                top + cropHeight
                            )
                        }

                        c.drawBitmap(
                            bitmap,
                            source,
                            target,
                            android.graphics.Paint(
                                android.graphics.Paint.ANTI_ALIAS_FLAG or
                                android.graphics.Paint.FILTER_BITMAP_FLAG
                            )
                        )

                        // Slideshow-Timer V2 steuert den naechsten Bildwechsel.
                    }
                }
                // EMBYFLOW_OVERVIEW_V3
                run {
                    val currentSlides = dailySlideEntries.filter {
                        dailySlidePosters[it.id] != null
                    }

                    if (currentSlides.isNotEmpty()) {
                        val currentIndex = stableSlideshowIndex % currentSlides.size

                        val currentMovie = currentSlides[currentIndex]

                        // Den bisherigen Verbindungshinweis
                        // und die ueberlagerten Texte abdecken.
                        val backgroundPaint = android.graphics.Paint().apply {
                            color = android.graphics.Color.rgb(11, 24, 39)
                            style = android.graphics.Paint.Style.FILL
                        }

                        c.drawRect(
                            249f, 192f, 980f, 276f,
                            backgroundPaint
                        )

                        val titlePaint = android.graphics.Paint(
                            android.graphics.Paint.ANTI_ALIAS_FLAG
                        ).apply {
                            color = android.graphics.Color.WHITE
                            textSize = 27f
                            isFakeBoldText = true
                        }

                        val overviewPaint = android.graphics.Paint(
                            android.graphics.Paint.ANTI_ALIAS_FLAG
                        ).apply {
                            color = android.graphics.Color.LTGRAY
                            textSize = 18f
                        }

                        // Lange Titel passend kuerzen.
                        var movieTitle = currentMovie.title

                        while (
                            movieTitle.length > 1 &&
                            titlePaint.measureText(movieTitle) > 695f
                        ) {
                            movieTitle = movieTitle.dropLast(1)
                        }

                        if (movieTitle != currentMovie.title) {
                            movieTitle = movieTitle.trimEnd() + "..."
                        }

                        c.drawText(
                            movieTitle,
                            252f,
                            218f,
                            titlePaint
                        )

                        val description = currentMovie.overview
                            .replace(Regex("<[^>]*>"), " ")
                            .replace(Regex("\\s+"), " ")
                            .trim()
                            .ifEmpty {
                                "Keine Inhaltsbeschreibung in Emby vorhanden."
                            }

                        // Beschreibung in maximal zwei gut
                        // lesbare Zeilen umbrechen.
                        val words = description.split(" ")
                        val lines = mutableListOf<String>()
                        var currentLine = ""

                        for (word in words) {
                            val candidate = if (currentLine.isEmpty()) {
                                word
                            } else {
                                "$currentLine $word"
                            }

                            if (
                                overviewPaint.measureText(candidate) <= 700f
                            ) {
                                currentLine = candidate
                            } else {
                                if (currentLine.isNotEmpty()) {
                                    lines.add(currentLine)
                                }
                                currentLine = word
                            }
                        }

                        if (currentLine.isNotEmpty()) {
                            lines.add(currentLine)
                        }

                        lines.take(2).forEachIndexed { index, line ->
                            var displayLine = line

                            if (index == 1 && lines.size > 2) {
                                while (
                                    displayLine.length > 1 &&
                                    overviewPaint.measureText(
                                        displayLine + "..."
                                    ) > 695f
                                ) {
                                    displayLine = displayLine.dropLast(1)
                                }

                                displayLine = displayLine.trimEnd() + "..."
                            }

                            c.drawText(
                                displayLine,
                                252f,
                                245f + index * 23f,
                                overviewPaint
                            )
                        }
                    }
                }
text(c, "Mediathek", 695f, 792f, 21f, cyan)

            text(c, mediaMessage.take(48), 695f, 822f, 16f)
            text(c, "Auswahl: ${mediaSelected + 1}", 695f, 847f, 16f)

            text(c, "Aktionen", 1120f, 792f, 21f, cyan)

            rectangle(c, 1125f, 813f, 16f, 16f, Color.RED)
            text(c, "Zurück", 1150f, 827f, 16f)

            rectangle(c, 1242f, 813f, 16f, 16f, Color.GREEN)
            text(c, "Abspielen", 1265f, 827f, 16f)

            rectangle(c, 1357f, 813f, 16f, 16f, Color.YELLOW)
            text(c, "Ein-/Ausloggen", 1380f, 827f, 16f)
        }

                fun handleKey(keyCode: Int): Boolean {

            if (categoryGridActive) {
                val last = (mediaEntries.size - 1).coerceAtLeast(0)

                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        mediaSelected = (mediaSelected + 1).coerceAtMost(last)
                    }

                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        mediaSelected = (mediaSelected - 1).coerceAtLeast(0)
                    }

                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        mediaSelected = (mediaSelected + 5).coerceAtMost(last)
                    }

                    KeyEvent.KEYCODE_DPAD_UP -> {
                        mediaSelected = (mediaSelected - 5).coerceAtLeast(0)
                    }

                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER,
                    KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                        playSelectedMedia()
                    }

                    else -> return false
                }

                invalidate()
                return true
            }

            if (resumeGridActive || categoryGridActive) {
                val last = (mediaEntries.size - 1).coerceAtLeast(0)

                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        mediaSelected = (mediaSelected + 1).coerceAtMost(last)
                    }

                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        mediaSelected = (mediaSelected - 1).coerceAtLeast(0)
                    }

                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        mediaSelected = (mediaSelected + 5).coerceAtMost(last)
                    }

                    KeyEvent.KEYCODE_DPAD_UP -> {
                        mediaSelected = (mediaSelected - 5).coerceAtLeast(0)
                    }

                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER,
                    KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                        playSelectedMedia()
                    }

                    else -> return false
                }

                invalidate()
                return true
            }

            when (keyCode) {

                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    if (focusArea == 0) {
                        selected = (selected + 1).coerceAtMost(menu.lastIndex)
                    } else if (focusArea == 2) {
                        mediaSelected =
                            (mediaSelected + 2).coerceAtMost(
                                (mediaEntries.size - 1).coerceAtLeast(0)
                            )
                    }
                }

                KeyEvent.KEYCODE_DPAD_UP -> {
                    if (focusArea == 0) {
                        selected = (selected - 1).coerceAtLeast(0)
                    } else if (focusArea == 2) {
                        mediaSelected = (mediaSelected - 2).coerceAtLeast(0)
                    }
                }

                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    when (focusArea) {
                        0 -> {
                            focusArea = 1
                            actionIndex = 0
                        }
                        1 -> {
                            if (mediaEntries.isNotEmpty()) {
                                focusArea = 2
                            } else {
                                actionIndex = 1
                            }
                        }
                        2 -> {
                            mediaSelected =
                                (mediaSelected + 1).coerceAtMost(
                                    (mediaEntries.size - 1).coerceAtLeast(0)
                                )
                        }
                    }
                }

                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    when (focusArea) {
                        2 -> {
                            if (mediaSelected > 0) {
                                mediaSelected--
                            } else {
                                focusArea = 1
                            }
                        }
                        1 -> {
                            focusArea = 0
                        }
                    }
                }

                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER,
                KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                    if (focusArea == 2) {
                        playSelectedMedia()
                    } else {
                        activate()
                    }
                }

                KeyEvent.KEYCODE_BACK -> {
                    focusArea = 0
                }

                else -> return false
            }

            invalidate()
            return true
        }
        private fun activate() { seriesLevel = 0
            val target = if (focusArea == 0) {
                menu[selected].trim()
            } else {
                actions[actionIndex]
            }

            when (target) {
                "Info / Einstellungen" -> openEmbySettings()

                "Weiterschauen" -> {
                    resumeGridActive = true
                    mediaSelected = 0
                    fetchMedia("Movie", resume = true)
                }

                "Start" -> {
                    resumeGridActive = false
                    fetchMedia("Movie")
                }

                "Filme" -> fetchMedia("Movie", section = "Filme")

                "Serien" -> fetchMedia("Series", section = "Serien")

                                // EMBYFLOW_NEUHEITEN_V1
                "Neu hinzugefügt" -> {
                    // EMBYFLOW_NEUHEITEN_E2_LAYOUT
                    startActivity(
                        Intent(
                            this@MainActivity,
                            NeuheitenActivity::class.java
                        )
                    )
                }

                "Filme 3D", "Filme 4K", "Filme O-Ton" ->
                    fetchMedia("Movie", section = target)

                "Serien 4K", "Serien Anime",
                "Serien Doku Reality", "Serien O-Ton" ->
                    fetchMedia("Series", section = target)

                "Hörbücher" ->
                    fetchMedia("Audio", section = target)

                "Konzerte Musik" ->
                    fetchMedia("MusicVideo", section = target)

                "Favoriten" -> fetchMedia(
                    "Movie,Series,Episode",
                    section = "Favoriten"
                )

                "Suche" -> {
                    val input = EditText(this@MainActivity).apply {
                        hint = "Titel eingeben"
                        setSingleLine(true)
                    }

                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("EmbyFlow Suche")
                        .setView(input)
                        .setNegativeButton("Abbrechen", null)
                        .setPositiveButton("Suchen") { _, _ ->
                            val query = input.text.toString().trim()

                            if (query.isNotBlank()) {
                                Toast.makeText(
                                    this@MainActivity,
                                    "Suche wird als Nächstes ergänzt.",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                        .show()
                }

                "Abspielen" -> playSelectedMedia()

                else -> Toast.makeText(
                    this@MainActivity,
                    target,
                    Toast.LENGTH_SHORT
                ).show()
            }

            invalidate()
        }
        override fun onTouchEvent(event: MotionEvent): Boolean {

            if (event.action == MotionEvent.ACTION_DOWN) {

                val x = event.x * 1649f / width
                val y = event.y * 928f / height

                if (x < 220f && y in 193f..735f) {
                    val index = ((y - 193f) / 29f).toInt()

                    if (index in menu.indices) {
                        selected = index
                        focusArea = 0
                        invalidate()
                        activate()
                    }
                } else if (y in 280f..330f) {
                    focusArea = 1
                    actionIndex = if (x < 452f) 0 else 1
                    invalidate()
                    activate()
                }

                return true
            }

            return true
        }
    }
}





