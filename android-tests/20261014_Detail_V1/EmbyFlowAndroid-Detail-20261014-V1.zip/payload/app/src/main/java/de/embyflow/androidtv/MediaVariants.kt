package de.embyflow.androidtv

import org.json.JSONObject
import java.text.Normalizer
import java.util.Locale

/** Metadata only: title text and filenames never imply a resolution. */
internal object MediaVariants {
    fun group(items: List<JSONObject>): List<List<JSONObject>> {
        val groups = linkedMapOf<String, MutableList<JSONObject>>()
        items.forEachIndexed { index, item ->
            val type = item.optString("Type").lowercase(Locale.ROOT)
            val title = Normalizer.normalize(item.optString("Name"), Normalizer.Form.NFKC)
                .lowercase(Locale.ROOT).trim().replace(Regex("\\s+"), " ")
            val year = item.optInt("ProductionYear", 0)
            val id = item.optString("Id")
            val key = if (type in listOf("movie", "series") && title.isNotBlank() && year > 0)
                "$type|$title|$year" else "id:${id.ifBlank { "row$index" }}"
            val values = groups.getOrPut(key) { mutableListOf() }
            if (id.isBlank() || values.none { it.optString("Id") == id }) values.add(item)
        }
        return groups.values.toList()
    }
    fun quality(item: JSONObject): Pair<String, String>? {
        val streams = mutableListOf<JSONObject>()
        val root = item.optJSONArray("MediaStreams")
        for (n in 0 until (root?.length() ?: 0)) root?.optJSONObject(n)?.let { streams.add(it) }
        val sources = item.optJSONArray("MediaSources")
        for (n in 0 until (sources?.length() ?: 0)) {
            val sourceStreams = sources?.optJSONObject(n)?.optJSONArray("MediaStreams")
            for (k in 0 until (sourceStreams?.length() ?: 0)) sourceStreams?.optJSONObject(k)?.let { streams.add(it) }
        }
        val video = streams.filter { it.optString("Type").equals("Video", true) }
            .maxByOrNull { it.optLong("Width", 0) * it.optLong("Height", 0) } ?: return null
        val width = video.optInt("Width", 0); val height = video.optInt("Height", 0)
        return when {
            width >= 3840 || height >= 2160 -> "4K" to "Ultra HD"
            width >= 1920 || height >= 1080 -> "1080p" to "Full HD"
            width >= 1280 || height >= 720 -> "720p" to "HD"
            height > 0 -> "${height}p" to ""
            width > 0 -> "$width px" to ""
            else -> null
        }
    }
}
