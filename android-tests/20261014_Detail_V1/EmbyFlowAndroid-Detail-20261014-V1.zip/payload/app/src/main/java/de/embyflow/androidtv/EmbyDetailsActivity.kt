package de.embyflow.androidtv

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

// EMBYFLOW_DETAILS_V1
class EmbyDetailsActivity : Activity() {
    private val navy = Color.rgb(11, 24, 39)
    private val panel = Color.rgb(16, 34, 52)
    private val cyan = Color.rgb(35, 215, 255)
    private val white = Color.rgb(237, 242, 250)
    private val muted = Color.rgb(179, 194, 210)
    private val prefs by lazy { getSharedPreferences("embyflow", MODE_PRIVATE) }
    private val server get() = prefs.getString("server", "").orEmpty().trimEnd('/')
    private val token get() = prefs.getString("token", "").orEmpty()
    private val userId get() = prefs.getString("userId", "").orEmpty()

    private var itemId = ""
    private var itemType = ""
    private var itemName = "Details"
    private var year = ""
    private var genres = ""
    private var runtime = ""
    private var overview = ""
    // EMBYFLOW_TECH_V4
    private var techRating = ""
    private var techFsk = ""
    private var techVideo = ""
    private var techAudio = ""
    private var techSubs = ""
    private var status = "Lade Details ..."
    private var poster: Bitmap? = null
    private var backdrop: Bitmap? = null
    private var selectedButton = 0
    private var resumeTicks = 0L
    private var playId = ""
    private var trailerId = ""
    private var trailerUrl = ""
    private var trailerAvailable = false
    // EMBYFLOW_TRAILER_V6
    private var trailerImdbId = ""
    private var loaded = false
    private var generation = 0
    private lateinit var screen: DetailsView
    private lateinit var detailRoot: android.widget.FrameLayout
    private var theme: DetailTheme? = null
    private var detailResumed = false

    private var director = ""
    private var actors = ""
    private var seasonCount = 0
    private var durationTicks = 0L
    private var mediaJson = JSONObject()
    private val trailersEnabled get() = prefs.getBoolean("trailers_enabled", true)
    private val buttons get() = if (itemType == "Series") {
        listOf("Staffel wählen") + (if (trailersEnabled) listOf("Trailer") else emptyList()) + "Zurück"
    } else {
        listOf(if (resumeTicks > 0L) "Fortsetzen" else "Abspielen") +
            (if (itemType != "Episode" && trailersEnabled) listOf("Trailer") else emptyList()) + "Zurück"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        itemId = intent.getStringExtra("item_id").orEmpty()
        itemType = intent.getStringExtra("item_type").orEmpty()
        itemName = intent.getStringExtra("item_title").orEmpty().ifBlank { "Details" }
        if (itemId.isBlank()) { finish(); return }
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        screen = DetailsView()
        screen.isFocusable = true
        screen.isFocusableInTouchMode = true
        detailRoot = android.widget.FrameLayout(this)
        detailRoot.addView(screen, android.widget.FrameLayout.LayoutParams(-1, -1))
        theme = DetailTheme(this, detailRoot) { screen.invalidate() }
        setContentView(detailRoot)
        screen.requestFocus()
        loadDetails()
    }

    private fun request(path: String): String {
        val connection = URL("$server$path").openConnection() as HttpURLConnection
        connection.connectTimeout = 9000
        connection.readTimeout = 12000
        connection.setRequestProperty("X-Emby-Token", token)
        return try {
            if (connection.responseCode !in 200..299) throw Exception("Emby HTTP ${connection.responseCode}")
            connection.inputStream.bufferedReader().use { it.readText() }
        } finally { connection.disconnect() }
    }

    private fun image(id: String, kind: String): Bitmap? {
        if (id.isBlank()) return null
        val suffix = if (kind == "Backdrop") "/0" else ""
        val connection = URL("$server/Items/$id/Images/$kind$suffix?maxWidth=1200")
            .openConnection() as HttpURLConnection
        connection.connectTimeout = 6000
        connection.readTimeout = 10000
        connection.setRequestProperty("X-Emby-Token", token)
        return try {
            if (connection.responseCode in 200..299)
                BitmapFactory.decodeStream(connection.inputStream)
            else null
        } finally { connection.disconnect() }
    }

    private fun loadDetails() {
        val current = ++generation
        thread {
            try {
                if (server.isBlank() || token.isBlank() || userId.isBlank()) {
                    throw Exception("Emby-Verbindung fehlt")
                }
                val json = JSONObject(request("/Users/$userId/Items/$itemId?Fields=MediaSources,MediaStreams,People,Genres,Overview,ChildCount"))
                val type = json.optString("Type", itemType)
                val imdbId = json.optJSONObject("ProviderIds")?.optString("Imdb", "").orEmpty()
                val name = json.optString("Name", itemName)
                val production = json.optInt("ProductionYear", 0)
                val description = json.optString("Overview", "")
                    .replace(Regex("<[^>]*>"), " ").replace(Regex("\\s+"), " ").trim()
                val genreArray = json.optJSONArray("Genres")
                val genreNames = (0 until (genreArray?.length() ?: 0))
                    .map { genreArray!!.optString(it) }.filter { it.isNotBlank() }.take(4).joinToString("  ·  ")
                val ticks = json.optLong("RunTimeTicks", 0L)
                val minutes = ticks / 600000000L
                val runTime = if (minutes > 0L) "$minutes Min." else ""
                var progress = json.optJSONObject("UserData")?.optLong("PlaybackPositionTicks", 0L) ?: 0L
                var count = 0
                if (type == "Series") try {
                    val seasons = JSONObject(request("/Shows/$itemId/Seasons?UserId=$userId"))
                    count = seasons.optInt("TotalRecordCount", seasons.optJSONArray("Items")?.length() ?: 0)
                } catch (_: Exception) { }
                val people = json.optJSONArray("People")
                val peopleList = (0 until (people?.length() ?: 0)).mapNotNull { people?.optJSONObject(it) }
                val directors = peopleList.filter { it.optString("Type").equals("Director", true) }.map { it.optString("Name") }.filter { it.isNotBlank() }.joinToString(", ")
                val cast = peopleList.filter { it.optString("Type").equals("Actor", true) }.take(12).map { it.optString("Name") }.filter { it.isNotBlank() }.joinToString(", ")
                var target = itemId
                var nextName = ""
                if (type == "Series") {
                    try {
                        val next = JSONObject(request(
                            "/Shows/NextUp?UserId=$userId&SeriesId=$itemId&Limit=1"
                        )).optJSONArray("Items")
                        val episode = next?.optJSONObject(0)
                        if (episode != null) {
                            target = episode.optString("Id", itemId)
                            nextName = episode.optString("Name", "")
                            progress = episode.optJSONObject("UserData")
                                ?.optLong("PlaybackPositionTicks", 0L) ?: 0L
                        } else {
                            target = ""
                            progress = 0L
                        }
                    } catch (_: Exception) {
                        target = ""
                        progress = 0L
                    }
                }
                // EMBYFLOW_TRAILER_WEBVIEW_V2
                // Kinocheck bevorzugen, sofern Emby mehrere RemoteTrailers hinterlegt hat.
                // EMBYFLOW_TECH_V4: Nur Metadaten des angemeldeten Benutzers lesen.
                val ratingNumber = json.optDouble("CommunityRating", 0.0)
                val ratingText = if (ratingNumber > 0.0 && !ratingNumber.isNaN())
                    String.format(java.util.Locale.GERMANY, "%.1f", ratingNumber) else ""
                val fskText = json.optString("OfficialRating", "")
                val mediaSource = json.optJSONArray("MediaSources")?.optJSONObject(0)
                val streams = mediaSource?.optJSONArray("MediaStreams")
                val videoStream = (0 until (streams?.length() ?: 0)).mapNotNull { streams?.optJSONObject(it) }
                    .firstOrNull { it.optString("Type").equals("Video", true) }
                val audioStreams = (0 until (streams?.length() ?: 0)).mapNotNull { streams?.optJSONObject(it) }
                    .filter { it.optString("Type").equals("Audio", true) }
                val subStreams = (0 until (streams?.length() ?: 0)).mapNotNull { streams?.optJSONObject(it) }
                    .filter { it.optString("Type").equals("Subtitle", true) }
                val videoWidth = videoStream?.optInt("Width", 0) ?: 0
                val resolution = when {
                    videoWidth >= 3800 -> "4K"
                    videoWidth >= 1900 -> "1080p"
                    videoWidth >= 1200 -> "720p"
                    videoWidth > 0 -> "SD"
                    else -> ""
                }
                val videoCodec = videoStream?.optString("Codec", "").orEmpty().uppercase(java.util.Locale.ROOT)
                val videoRange = videoStream?.optString("VideoRangeType", "").orEmpty()
                    .ifBlank { videoStream?.optString("VideoRange", "").orEmpty() }
                val videoText = listOf(resolution, videoRange, videoCodec)
                    .filter { it.isNotBlank() }.joinToString("  ·  ")
                val defaultAudio = audioStreams.firstOrNull { it.optBoolean("IsDefault", false) }
                    ?: audioStreams.firstOrNull()
                val defaultSub = subStreams.firstOrNull { it.optBoolean("IsDefault", false) }
                    ?: subStreams.firstOrNull()
                fun streamText(stream: JSONObject?, isAudio: Boolean): String {
                    if (stream == null) return ""
                    val language = stream.optString("Language", "").let {
                        when (it.lowercase(java.util.Locale.ROOT)) {
                            "de", "deu", "ger" -> "Deutsch"
                            "en", "eng" -> "Englisch"
                            else -> it
                        }
                    }
                    val codec = stream.optString("Codec", "").uppercase(java.util.Locale.ROOT)
                    val channels = if (isAudio) when (stream.optInt("Channels", 0)) {
                        1 -> "Mono"; 2 -> "Stereo"; 6 -> "5.1"; 8 -> "7.1"; else -> ""
                    } else ""
                    return listOf(language, codec, channels).filter { it.isNotBlank() }.joinToString("  ·  ")
                }
                val audioText = streamText(defaultAudio, true)
                val subText = streamText(defaultSub, false)
                val remoteTrailers = json.optJSONArray("RemoteTrailers")
                var remoteUrl = ""
                var bestScore = -1
                if (remoteTrailers != null) {
                    for (i in 0 until remoteTrailers.length()) {
                        val entry = remoteTrailers.optJSONObject(i) ?: continue
                        val url = entry.optString("Url", "")
                        if (!url.startsWith("https://") && !url.startsWith("http://")) continue
                        // EMBYFLOW_TRAILER_V5: Nur direkte, explizit hinterlegte Videos.
                        // Eine YouTube-Suche ist keine bestaetigte Trailer-Quelle.
                        val directId = Regex("(?:youtu\\.be/|youtube(?:-nocookie)?\\.com/(?:watch\\?v=|embed/|shorts/|live/))([A-Za-z0-9_-]{11})")
                            .find(url)?.groupValues?.getOrNull(1)
                        if (directId == null) continue
                        val title = entry.optString("Name", "").trim()
                        // Widersprechende Jahreszahlen in Emby-Trailern aussortieren.
                        val candidateYears = Regex("\\b(?:19|20)\\d{2}\\b").findAll(title)
                            .map { it.value.toIntOrNull() ?: 0 }.filter { it > 0 }.toList()
                        if (production > 0 && candidateYears.isNotEmpty() && production !in candidateYears) continue
                        val source = (title + " " + entry.optString("SiteName", ""))
                        val score = if (source.contains("kinocheck", true) || source.contains("kino check", true)) 10 else 1
                        if (score > bestScore) { bestScore = score; remoteUrl = url }
                    }
                }
                var localId = ""
                try {
                    val local = JSONArray(request("/Users/$userId/Items/$itemId/LocalTrailers"))
                    localId = local.optJSONObject(0)?.optString("Id", "").orEmpty()
                } catch (_: Exception) { }
                var hero: Bitmap? = null
                var cover: Bitmap? = null
                try { hero = image(itemId, "Backdrop") } catch (_: Exception) { }
                if (hero == null) try {
                    hero = image(itemId, "Thumb")
                } catch (_: Exception) { }
                if (hero == null && type == "Episode") {
                    val series = json.optString("SeriesId", "")
                    try { hero = image(series, "Backdrop") } catch (_: Exception) { }
                }
                try { cover = image(itemId, "Primary") } catch (_: Exception) { }
                runOnUiThread {
                    if (current != generation || isFinishing || isDestroyed) return@runOnUiThread
                    mediaJson = json
                    durationTicks = ticks
                    seasonCount = count
                    director = directors
                    actors = cast
                    itemType = type
                    itemName = name
                    year = if (production > 0) production.toString() else ""
                    overview = description.ifBlank { "Keine Inhaltsbeschreibung hinterlegt." }
                    genres = genreNames
                    runtime = runTime
                    techRating = ratingText
                    techFsk = fskText
                    techVideo = videoText
                    techAudio = audioText
                    techSubs = subText
                    resumeTicks = progress
                    playId = target
                    trailerId = localId
                    trailerUrl = remoteUrl
                    trailerAvailable = localId.isNotBlank() || remoteUrl.isNotBlank()
                    trailerImdbId = imdbId
                    poster = cover
                    backdrop = hero
                    status = if (type == "Series" && target.isNotBlank()) {
                        if (nextName.isNotBlank()) "Nächste Folge: $nextName" else "Serie fortsetzen"
                    } else if (type == "Series") "Staffel auswählen" else ""
                    selectedButton = 0
                    loaded = true
                    restartTheme()
                    screen.invalidate()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (current == generation) {
                        status = "Details konnten nicht geladen werden: ${e.message}"
                        screen.invalidate()
                    }
                }
            }
        }
    }

    private fun startPlayer(id: String, fromBeginning: Boolean) {
        if (id.isBlank()) {
            Toast.makeText(this, "Bitte zuerst eine Folge auswählen.", Toast.LENGTH_LONG).show()
            return
        }
        val encoded = URLEncoder.encode(token, "UTF-8")
        val address = "$server/Videos/$id/stream?static=true&api_key=$encoded"
        startActivity(Intent(this, EmbyPlayerActivity::class.java).apply {
            putExtra("stream_url", address)
            putExtra("item_id", id)
            putExtra("start_from_beginning", fromBeginning)
        })
    }

    private fun activate() {
        if (!loaded) return
        when (buttons.getOrNull(selectedButton)) {
            "Abspielen", "Fortsetzen" -> startPlayer(playId, false)
            "Von Anfang" -> startPlayer(playId, true)
            "Staffel wählen" -> {
                SeasonChooser.show(this, itemId, itemName) { episode ->
                    startActivity(Intent(this, EmbyDetailsActivity::class.java).apply {
                        putExtra("item_id", episode.optString("Id"))
                        putExtra("item_type", "Episode")
                        putExtra("item_title", episode.optString("Name"))
                    })
                }
            }
            "Trailer" -> {
                when {
                    trailerId.isNotBlank() -> startPlayer(trailerId, true)
                    trailerUrl.isNotBlank() -> {
                        try {
                            startActivity(Intent(this, EmbyTrailerActivity::class.java).apply {
                                putExtra("trailer_url", trailerUrl)
                                putExtra("item_title", itemName)
                                putExtra("item_year", year)
                                putExtra("trailer_imdb_id", trailerImdbId)
                                putExtra("item_type", itemType)
                            })
                        } catch (_: Exception) {
                            Toast.makeText(this, "Kein Browser für diesen Trailer verfügbar.", Toast.LENGTH_LONG).show()
                        }
                    }
                    else -> startActivity(Intent(this, EmbyTrailerActivity::class.java).apply {
                        putExtra("trailer_imdb_id", trailerImdbId)
                        putExtra("item_type", itemType)
                        putExtra("item_title", itemName)
                        putExtra("item_year", year)
                    })
                }
            }
            "Zurück" -> finish()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_MENU -> { showDetailSettings(); return true }
            KeyEvent.KEYCODE_DPAD_LEFT -> selectedButton = (selectedButton - 1).coerceAtLeast(0)
            KeyEvent.KEYCODE_DPAD_RIGHT -> selectedButton = (selectedButton + 1).coerceAtMost(buttons.lastIndex)
            KeyEvent.KEYCODE_DPAD_UP -> selectedButton = (selectedButton - 1).coerceAtLeast(0)
            KeyEvent.KEYCODE_DPAD_DOWN -> selectedButton = (selectedButton + 1).coerceAtMost(buttons.lastIndex)
            KeyEvent.KEYCODE_CHANNEL_UP -> screen.scrollDescription(-1)
            KeyEvent.KEYCODE_CHANNEL_DOWN -> screen.scrollDescription(1)
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> activate()
            KeyEvent.KEYCODE_BACK -> { finish(); return true }
            else -> return super.onKeyDown(keyCode, event)
        }
        screen.invalidate()
        return true
    }

    private fun restartTheme() {
        if (loaded && detailResumed) theme?.start(itemId, prefs.getString("detail_theme_mode", "off").orEmpty())
    }
    override fun onResume() { super.onResume(); detailResumed = true; restartTheme() }
    override fun onPause() { detailResumed = false; theme?.stop(); super.onPause() }
    override fun onDestroy() { generation++; theme?.stop(); theme = null; super.onDestroy() }

    private fun showDetailSettings() {
        val labels = arrayOf("Trailer anzeigen", "Hintergrundmusik / -video")
        android.app.AlertDialog.Builder(this).setTitle("Detailansicht").setItems(labels) { _, which ->
            if (which == 0) {
                android.app.AlertDialog.Builder(this).setTitle("Trailer anzeigen")
                    .setSingleChoiceItems(arrayOf("Aus", "Ein"), if (trailersEnabled) 1 else 0) { dialog, index ->
                        prefs.edit().putBoolean("trailers_enabled", index == 1).apply()
                        selectedButton = selectedButton.coerceAtMost(buttons.lastIndex)
                        screen.invalidate(); dialog.dismiss()
                    }.show()
            } else {
                val modes = arrayOf("off", "music", "video")
                android.app.AlertDialog.Builder(this).setTitle("Emby-Hintergrundmedien")
                    .setSingleChoiceItems(arrayOf("Nur Fanart", "Theme-Musik", "Theme-Video"), modes.indexOf(prefs.getString("detail_theme_mode", "off")).coerceAtLeast(0)) { dialog, index ->
                        prefs.edit().putString("detail_theme_mode", modes[index]).apply()
                        restartTheme(); dialog.dismiss()
                    }.show()
            }
        }.show()
    }

    private inner class DetailsView : View(this@EmbyDetailsActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private var descriptionScroll = 0
        private val artwork = mutableMapOf<String, Bitmap>()
        init {
            for (name in listOf("button_focus", "button_normal", "info_badge", "detail_gradient_navy", "series_vertical_gradient_v8")) {
                try { assets.open("embyflow/$name.png").use { BitmapFactory.decodeStream(it)?.let { b -> artwork[name] = b } } }
                catch (_: Exception) { }
            }
        }
        private fun label(c: Canvas, value: String, x: Float, y: Float, size: Float, color: Int = white, bold: Boolean = false, maxWidth: Float = 1190f) {
            paint.color = color; paint.textSize = size; paint.typeface = if (bold) android.graphics.Typeface.DEFAULT_BOLD else android.graphics.Typeface.DEFAULT
            var shown = value
            if (paint.measureText(shown) > maxWidth) shown = shown.take(paint.breakText(shown, true, (maxWidth - paint.measureText("…")).coerceAtLeast(0f), null)) + "…"
            c.drawText(shown, x, y, paint)
        }
        private fun lines(value: String, maxWidth: Float, size: Float, bold: Boolean = false): List<String> {
            paint.textSize = size; paint.typeface = if (bold) android.graphics.Typeface.DEFAULT_BOLD else android.graphics.Typeface.DEFAULT
            val output = mutableListOf<String>()
            for (paragraph in value.split('\n')) {
                var line = ""
                for (word in paragraph.split(Regex("\\s+"))) {
                    if (word.isEmpty()) continue
                    val candidate = if (line.isEmpty()) word else "$line $word"
                    if (paint.measureText(candidate) > maxWidth && line.isNotEmpty()) { output.add(line); line = "" }
                    var rest = word
                    if (line.isEmpty()) {
                        while (paint.measureText(rest) > maxWidth) {
                            val count = paint.breakText(rest, true, maxWidth, null).coerceAtLeast(1)
                            output.add(rest.take(count)); rest = rest.drop(count)
                        }
                        line = rest
                    } else line = candidate
                }
                if (line.isNotBlank()) output.add(line)
            }
            return output
        }
        fun scrollDescription(delta: Int) { descriptionScroll = (descriptionScroll + delta).coerceAtLeast(0); invalidate() }
        private fun bitmap(c: Canvas, image: Bitmap?, rect: RectF, cover: Boolean = false) {
            if (image == null) return
            c.save(); c.clipRect(rect)
            val scale = if (cover) maxOf(rect.width() / image.width, rect.height() / image.height) else minOf(rect.width() / image.width, rect.height() / image.height)
            val w = image.width * scale; val h = image.height * scale
            c.drawBitmap(image, null, RectF(rect.centerX() - w / 2, rect.centerY() - h / 2, rect.centerX() + w / 2, rect.centerY() + h / 2), paint)
            c.restore()
        }
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            if (theme?.videoVisible != true) c.drawColor(Color.rgb(12, 24, 39))
            val scale = minOf(width / 1920f, height / 1080f)
            c.save(); c.translate((width - 1920 * scale) / 2, (height - 1080 * scale) / 2); c.scale(scale, scale)
            paint.alpha = 255
            if (theme?.videoVisible != true) bitmap(c, backdrop, RectF(0f, 0f, 1920f, 1080f), true)
            val gradient = artwork[if (itemType == "Series") "series_vertical_gradient_v8" else "detail_gradient_navy"]
            if (gradient != null) c.drawBitmap(gradient, null, RectF(0f, 0f, 1920f, 1080f), paint)
            else { paint.color = Color.argb(200, 12, 24, 39); c.drawRect(0f, 0f, 1920f, 1080f, paint) }
            label(c, "EMBYFLOW", 90f, 100f, 24f, cyan)
            var titleSize = 64f
            var titleLines = lines(itemName, 1190f, titleSize, true)
            while (titleLines.size > 2 && titleSize > 36f) { titleSize -= 2f; titleLines = lines(itemName, 1190f, titleSize, true) }
            titleLines.take(3).forEachIndexed { index, row -> label(c, row, 90f, 190f + index * (titleSize + 8), titleSize, white, true) }
            val badges = mutableListOf<String>()
            if (techRating.isNotBlank()) badges.add("★ $techRating")
            if (year.isNotBlank()) badges.add(year)
            if (itemType == "Series") { if (seasonCount > 0) badges.add("$seasonCount Staffeln") }
            else if (runtime.isNotBlank()) badges.add(runtime)
            if (techFsk.isNotBlank()) badges.add(techFsk)
            if (itemType != "Series") {
                MediaVariants.quality(mediaJson)?.first?.let { badges.add(it) }
                if (techAudio.isNotBlank()) badges.add(techAudio)
                if (techSubs.isNotBlank()) badges.add("UT")
                val remaining = (durationTicks - resumeTicks).coerceAtLeast(0L)
                if (remaining > 0) badges.add("Endet um " + java.text.SimpleDateFormat("HH:mm", java.util.Locale.GERMANY).format(java.util.Date(System.currentTimeMillis() + remaining / 10000L)))
            }
            var bx = 90f; var by = 325f
            for (badge in badges) {
                paint.textSize = 25f; paint.typeface = android.graphics.Typeface.DEFAULT
                val bw = (paint.measureText(badge) + 30).coerceIn(76f, 400f)
                if (bx + bw > 1280f) { bx = 90f; by += 59f }
                if (by > 384f) break
                val r = RectF(bx, by, bx + bw, by + 48f)
                artwork["info_badge"]?.let { c.drawBitmap(it, null, r, paint) }
                    ?: run { paint.color = panel; c.drawRoundRect(r, 7f, 7f, paint) }
                label(c, badge, bx + 15f, by + 33f, 25f, if (badge.startsWith("★")) 0xffe7c53d.toInt() else white, maxWidth = bw - 30)
                bx += bw + 12
            }
            label(c, genres, 90f, 467f, 25f, muted)
            label(c, "Inhaltsangabe", 90f, 530f, 32f, white, true)
            val content = lines(overview, 930f, 30f)
            val visible = 6
            descriptionScroll = descriptionScroll.coerceIn(0, (content.size - visible).coerceAtLeast(0))
            content.drop(descriptionScroll).take(visible).forEachIndexed { i, row -> label(c, row, 90f, 586f + i * 37f, 30f, maxWidth = 930f) }
            if (content.size > visible) label(c, "Inhalt: CH+/CH− blättern · ${descriptionScroll + 1}–${minOf(descriptionScroll + visible, content.size)}/${content.size}", 90f, 817f, 22f, cyan)
            label(c, "Regie", 90f, 864f, 26f, muted, maxWidth = 150f)
            label(c, director.ifBlank { "—" }, 245f, 864f, 26f, maxWidth = 1000f)
            label(c, "Darsteller", 90f, 914f, 24f, muted, maxWidth = 150f)
            lines(actors.ifBlank { "—" }, 1030f, 24f).take(2).forEachIndexed { i, row -> label(c, row, 245f, 914f + i * 32, 24f, maxWidth = 1030f) }
            bitmap(c, poster, RectF(1510f, 80f, 1840f, 575f))
            buttons.forEachIndexed { index, button ->
                val y = 615f + index * 95f
                val r = RectF(1506f, y - 4, 1844f, y + 76)
                artwork[if (index == selectedButton) "button_focus" else "button_normal"]?.let { c.drawBitmap(it, null, r, paint) }
                    ?: run { paint.color = if (index == selectedButton) cyan else panel; c.drawRoundRect(r, 12f, 12f, paint) }
                val caption = when (button) { "Abspielen", "Fortsetzen" -> "▶  $button"; "Zurück" -> "←  Zurück"; "Trailer" -> "▣  Trailer"; else -> button }
                paint.textSize = 30f
                label(c, caption, r.centerX() - paint.measureText(caption) / 2, y + 46f, 30f, white, index == selectedButton, 322f)
            }
            label(c, status, 90f, 996f, 22f, muted)
            label(c, "▲/▼ Auswahl · OK Öffnen · MENU Trailer / Hintergrund · Zurück", 90f, 1040f, 22f, muted)
            c.restore()
        }
    }
}
