package de.embyflow.androidtv

import android.app.Activity
import android.app.Dialog
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.KeyEvent
import android.view.View
import android.view.Window
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

internal object QualityChooser {
    fun show(activity: Activity, title: String, variants: List<JSONObject>, accept: (JSONObject) -> Unit) {
        if (variants.isEmpty()) return
        if (variants.size == 1) { accept(variants[0]); return }
        val dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val qualities = variants.map { MediaVariants.quality(it) }.toMutableList()
        val pending = qualities.map { it == null }.toMutableList()
        var selected = 0
        val closed = java.util.concurrent.atomic.AtomicBoolean(false)
        val missing = pending.indices.filter { pending[it] }
        val prefs = activity.getSharedPreferences("embyflow", Activity.MODE_PRIVATE)
        val server = prefs.getString("server", "").orEmpty().trimEnd('/')
        val token = prefs.getString("token", "").orEmpty()
        val user = prefs.getString("userId", "").orEmpty()
        val view = object : View(activity) {
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            fun text(c: Canvas, value: String, x: Float, y: Float, size: Float, color: Int, max: Float) {
                paint.color = color; paint.textSize = size
                var shown = value
                if (paint.measureText(shown) > max) shown = shown.take(paint.breakText(shown, true, max - paint.measureText("…"), null)) + "…"
                c.drawText(shown, x, y, paint)
            }
            override fun onDraw(c: Canvas) {
                c.save(); c.scale(width / 1280f, height / 735f)
                c.drawColor(Color.rgb(12, 24, 39))
                text(c, "EMBYFLOW", 50f, 55f, 25f, 0xff26dff5.toInt(), 1180f)
                text(c, title, 50f, 130f, 42f, Color.WHITE, 1180f)
                text(c, "Wiedergabequalität auswählen", 50f, 215f, 27f, 0xffb7c5d5.toInt(), 1180f)
                val first = selected / 5 * 5
                for (slot in 0..4) {
                    val index = first + slot; if (index >= variants.size) break
                    val y = 250f + slot * 76f
                    paint.color = if (index == selected) 0xff26dff5.toInt() else 0xff172b40.toInt()
                    c.drawRoundRect(RectF(50f, y, 1230f, y + 64f), 5f, 5f, paint)
                    val color = if (index == selected) 0xff0c1827.toInt() else Color.WHITE
                    val quality = qualities[index]
                    val label = quality?.first ?: if (pending[index]) "Wird ermittelt …" else "Auflösung unbekannt"
                    var info = quality?.second.orEmpty()
                    if (quality != null && qualities.count { it == quality } > 1) info += " · Version ${qualities.take(index + 1).count { it == quality }}"
                    text(c, label, 75f, y + 43f, 33f, color, 640f)
                    text(c, info, 770f, y + 43f, 26f, color, 440f)
                }
                text(c, "↑ / ↓ Auswahl     OK Öffnen     Zurück Abbrechen     ${selected + 1}/${variants.size}", 50f, 695f, 24f, 0xffb7c5d5.toInt(), 1180f)
                c.restore()
            }
            override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP -> selected = (selected - 1 + variants.size) % variants.size
                    KeyEvent.KEYCODE_DPAD_DOWN -> selected = (selected + 1) % variants.size
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { val chosen = variants[selected]; dialog.dismiss(); accept(chosen); return true }
                    else -> return super.onKeyDown(keyCode, event)
                }
                invalidate(); return true
            }
        }
        view.isFocusableInTouchMode = true
        dialog.setContentView(view)
        dialog.setOnDismissListener { closed.set(true) }
        dialog.show()
        val display = activity.resources.displayMetrics
        dialog.window?.setLayout((display.widthPixels * .78f).toInt(), (display.heightPixels * .80f).toInt())
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        view.requestFocus()
        thread {
            variants.forEachIndexed { index, variant ->
                if (closed.get() || activity.isFinishing || activity.isDestroyed) return@thread
                if (index !in missing) return@forEachIndexed
                var quality: Pair<String, String>? = null
                try {
                    val id = java.net.URLEncoder.encode(variant.optString("Id"), "UTF-8")
                    val connection = URL("$server/Users/$user/Items/$id?Fields=MediaSources,MediaStreams").openConnection() as HttpURLConnection
                    connection.connectTimeout = 8000; connection.readTimeout = 8000
                    connection.setRequestProperty("X-Emby-Token", token)
                    try { if (connection.responseCode in 200..299) quality = MediaVariants.quality(JSONObject(connection.inputStream.bufferedReader().use { it.readText() })) }
                    finally { connection.disconnect() }
                } catch (_: Exception) { }
                val result = quality
                activity.runOnUiThread { if (!closed.get() && !activity.isFinishing && !activity.isDestroyed) { qualities[index] = result; pending[index] = false; view.invalidate() } }
            }
        }
    }
}
