package de.embyflow.androidtv

import android.app.Activity
import android.app.Dialog
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.KeyEvent
import android.view.View
import android.view.Window
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

/** Season/episode list over the unchanged series fanart; no season poster strip. */
internal object SeasonChooser {
    fun show(activity: Activity, seriesId: String, seriesTitle: String, accept: (JSONObject) -> Unit) {
        val dialog = Dialog(activity); dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        var rows = emptyList<JSONObject>(); var seasons = emptyList<JSONObject>()
        var selected = 0; var seasonSelection = 0
        var episodes = false; var loading = true; var status = "Wird geladen …"
        var subtitle = "Staffel wählen"; var generation = 0; var closed = false
        val prefs = activity.getSharedPreferences("embyflow", Activity.MODE_PRIVATE)
        val server = prefs.getString("server", "").orEmpty().trimEnd('/')
        val token = prefs.getString("token", "").orEmpty()
        val user = prefs.getString("userId", "").orEmpty()
        lateinit var load: (String) -> Unit
        val view = object : View(activity) {
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            fun label(c: Canvas, value: String, x: Float, y: Float, size: Float, color: Int, max: Float) {
                paint.textSize = size; paint.color = color
                val count = paint.breakText(value, true, (max - paint.measureText("…")).coerceAtLeast(0f), null)
                c.drawText(if (paint.measureText(value) > max) value.take(count) + "…" else value, x, y, paint)
            }
            override fun onDraw(c: Canvas) {
                c.save(); c.scale(width / 820f, height / 950f); c.drawColor(0xff0c1827.toInt())
                label(c, "EMBYFLOW", 40f, 55f, 25f, 0xff26dff5.toInt(), 740f)
                label(c, seriesTitle, 40f, 112f, 35f, Color.WHITE, 740f)
                label(c, subtitle, 40f, 165f, 29f, 0xffb7c5d5.toInt(), 740f)
                val first = selected / 8 * 8
                for (slot in 0..7) {
                    val row = rows.getOrNull(first + slot) ?: break
                    val y = 200f + slot * 80f
                    paint.color = if (first + slot == selected) 0xff233343.toInt() else 0xff17212c.toInt()
                    c.drawRoundRect(RectF(30f, y, 790f, y + 70), 6f, 6f, paint)
                    val name = row.optString("Name", "Ohne Titel")
                    val prefix = if (episodes && row.has("IndexNumber")) "%02d  ".format(row.optInt("IndexNumber")) else ""
                    label(c, prefix + name, 50f, y + 46f, 29f, if (first + slot == selected) 0xff35d3e8.toInt() else Color.WHITE, 720f)
                }
                if (loading || rows.isEmpty()) label(c, status, 40f, 260f, 27f, Color.WHITE, 740f)
                label(c, "↑/↓ Auswahl · OK Öffnen · Zurück", 40f, 907f, 23f, 0xffb7c5d5.toInt(), 740f)
                c.restore()
            }
            override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
                when (keyCode) {
                    KeyEvent.KEYCODE_BACK -> {
                        if (episodes) {
                            generation++; episodes = false; rows = seasons; selected = seasonSelection
                            subtitle = "Staffel wählen"; loading = false; status = if (rows.isEmpty()) "Keine Staffeln vorhanden." else ""
                        } else dialog.dismiss()
                    }
                    KeyEvent.KEYCODE_DPAD_UP -> selected = (selected - 1).coerceAtLeast(0)
                    KeyEvent.KEYCODE_DPAD_DOWN -> selected = (selected + 1).coerceAtMost((rows.size - 1).coerceAtLeast(0))
                    KeyEvent.KEYCODE_CHANNEL_UP -> selected = (selected - 8).coerceAtLeast(0)
                    KeyEvent.KEYCODE_CHANNEL_DOWN -> selected = (selected + 8).coerceAtMost((rows.size - 1).coerceAtLeast(0))
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                        if (!loading) rows.getOrNull(selected)?.let { row ->
                            if (episodes) { dialog.dismiss(); accept(row) }
                            else { seasonSelection = selected; episodes = true; subtitle = row.optString("Name", "Folgen"); load(row.optString("Id")) }
                        }
                    }
                    else -> return super.onKeyDown(keyCode, event)
                }
                invalidate(); return true
            }
        }
        load = { seasonId ->
            val current = ++generation; val episodeMode = seasonId.isNotBlank()
            selected = 0; rows = emptyList(); loading = true; status = "Wird geladen …"; view.invalidate()
            thread {
                var result = emptyList<JSONObject>(); var error = ""
                try {
                    val path = if (episodeMode) "/Shows/${URLEncoder.encode(seriesId, "UTF-8")}/Episodes?UserId=$user&SeasonId=${URLEncoder.encode(seasonId, "UTF-8")}&Fields=Overview,UserData,ParentIndexNumber,IndexNumber"
                        else "/Shows/${URLEncoder.encode(seriesId, "UTF-8")}/Seasons?UserId=$user"
                    val connection = URL(server + path).openConnection() as HttpURLConnection
                    connection.connectTimeout = 8000; connection.readTimeout = 12000
                    connection.setRequestProperty("X-Emby-Token", token)
                    val data = try {
                        if (connection.responseCode !in 200..299) throw Exception("Emby HTTP ${connection.responseCode}")
                        JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
                    } finally { connection.disconnect() }
                    val items = data.optJSONArray("Items")
                    result = (0 until (items?.length() ?: 0)).mapNotNull { items?.optJSONObject(it) }.sortedBy { it.optInt("IndexNumber", 0) }
                } catch (_: Exception) { error = "Liste konnte nicht geladen werden. Bitte erneut öffnen." }
                val loaded = result; val message = error
                activity.runOnUiThread {
                    if (!closed && !activity.isFinishing && !activity.isDestroyed && current == generation) {
                        rows = loaded; if (!episodeMode) seasons = loaded
                        loading = false; status = message.ifBlank { if (loaded.isEmpty()) "Keine Einträge vorhanden." else "" }; view.invalidate()
                    }
                }
            }
        }
        view.isFocusableInTouchMode = true; dialog.setContentView(view)
        dialog.setOnDismissListener { closed = true; generation++ }
        dialog.show()
        val display = activity.resources.displayMetrics
        dialog.window?.setLayout((display.heightPixels * .76f).toInt().coerceAtMost((display.widthPixels * .8f).toInt()), (display.heightPixels * .88f).toInt())
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        view.requestFocus(); load("")
    }
}
