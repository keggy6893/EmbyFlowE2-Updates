package de.embyflow.androidtv
import org.json.JSONObject
fun main() {
    var count = 0
    fun test(value: Boolean, name: String) { check(value) { name }; count++ }
    fun item(id: String, name: String, year: Int, type: String = "Movie") = JSONObject().put("Id", id).put("Name", name).put("ProductionYear", year).put("Type", type)
    val first = item("a", "Film", 2026)
    val other = item("b", "  FILM  ", 2026)
    test(MediaVariants.group(listOf(first, other)).single().size == 2, "same movie/year groups")
    test(MediaVariants.group(listOf(first, item("b", "Film", 2001))).size == 2, "remakes remain separate")
    test(MediaVariants.group(listOf(first, first)).single().size == 1, "same id not duplicated")
    test(MediaVariants.group(listOf(item("a", "Film", 0), item("b", "Film", 0))).size == 2, "unknown years never merged")
    test(MediaVariants.group(listOf(item("a", "Pilot", 2026, "Episode"), item("b", "Pilot", 2026, "Episode"))).size == 2, "episodes remain separate")
    test(MediaVariants.group(listOf(first, item("b", "Film", 2026, "Series"))).size == 2, "types remain separate")
    test(MediaVariants.quality(item("a", "Film 4K", 2026)) == null, "title does not imply quality")
    fun stream(w: Int, h: Int) = JSONObject().put("Type", "Video").put("Width", w).put("Height", h)
    fun quality(w: Int, h: Int) = MediaVariants.quality(JSONObject().put("MediaStreams", org.json.JSONArray().put(stream(w,h))))?.first
    test(quality(3840,1600) == "4K", "cropped UHD from width")
    test(quality(1920,800) == "1080p", "cropped FHD from width")
    test(quality(1280,720) == "720p", "HD")
    test(quality(720,576) == "576p", "SD actual height")
    test(quality(0,0) == null, "unknown dimensions")
    val nested = JSONObject().put("MediaSources", org.json.JSONArray().put(JSONObject().put("MediaStreams", org.json.JSONArray().put(stream(3840,2160)))))
    test(MediaVariants.quality(nested)?.first == "4K", "nested media sources")
    test(MediaVariants.quality(JSONObject().put("MediaStreams", org.json.JSONArray().put(JSONObject().put("Type","Audio").put("Width",3840)))) == null, "audio not video")
    println("$count metadata checks passed")
}
